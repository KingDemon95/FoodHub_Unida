const CACHE_NAME = 'foodhub-unida-v2';
const STATIC_CACHE = [
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png'
];

// Install event - cache only critical static resources
self.addEventListener('install', (event) => {
  console.log('[SW] Installing service worker...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Caching static assets');
        return cache.addAll(STATIC_CACHE).catch((error) => {
          console.error('[SW] Failed to cache static assets:', error);
        });
      })
  );
  self.skipWaiting();
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating service worker...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('[SW] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  return self.clients.claim();
});

// Fetch event - MINIMAL intervention
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // CRITICAL: Let ALL API calls, authentication, and external requests pass through
  // without any intervention from service worker
  if (
    // Skip all non-GET requests
    event.request.method !== 'GET' ||
    // Skip all Supabase requests
    url.hostname.includes('supabase') ||
    // Skip all authentication endpoints
    url.pathname.includes('/auth/') ||
    url.pathname.includes('/functions/') ||
    // Skip all external domains
    url.origin !== self.location.origin ||
    // Skip chrome extensions
    url.protocol === 'chrome-extension:' ||
    // Skip websockets
    url.protocol === 'ws:' ||
    url.protocol === 'wss:'
  ) {
    // Don't intervene at all - let it go directly to network
    return;
  }

  // Only handle our own static assets
  // Use network-first strategy for everything else
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Only cache successful responses for our own static files
        if (response && response.status === 200 && response.type === 'basic') {
          // Only cache specific file types
          if (url.pathname.match(/\.(png|jpg|jpeg|svg|gif|ico|json)$/)) {
            const responseToCache = response.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
          }
        }
        return response;
      })
      .catch((error) => {
        console.error('[SW] Fetch failed:', error);
        // Try cache only for static assets
        return caches.match(event.request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }
          // Don't return error responses for API calls
          throw error;
        });
      })
  );
});

// Listen for messages from the app
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
