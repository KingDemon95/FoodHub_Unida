# 📱 Panduan Install FOODHUB UNIDA sebagai Aplikasi Mobile

Aplikasi FOODHUB UNIDA sekarang mendukung **Progressive Web App (PWA)**, yang berarti Anda dapat menginstallnya seperti aplikasi native di smartphone atau tablet Anda!

## ✨ Keuntungan Install sebagai App:

- ✅ **Akses cepat** - Langsung dari home screen, tanpa buka browser
- ✅ **Tampilan full screen** - Tidak ada browser bar yang mengganggu
- ✅ **Icon di home screen** - Seperti aplikasi biasa
- ✅ **Offline support** - Beberapa fitur tetap bisa diakses tanpa internet
- ✅ **Notifikasi** - Dapat notifikasi pesanan (jika diaktifkan)
- ✅ **Performa lebih baik** - Loading lebih cepat

---

## 📲 Cara Install di Android (Chrome/Edge):

1. **Buka website** FOODHUB UNIDA di browser Chrome atau Edge
2. Anda akan melihat **banner "Install FOODHUB UNIDA"** di bagian bawah layar
3. Tap tombol **"Install"**
4. Konfirmasi dengan tap **"Install"** lagi di popup
5. ✅ Selesai! Icon aplikasi akan muncul di home screen

### Cara Manual (jika banner tidak muncul):
1. Tap **menu titik tiga** (⋮) di pojok kanan atas Chrome
2. Pilih **"Install app"** atau **"Add to Home screen"**
3. Tap **"Install"**
4. ✅ Selesai!

---

## 🍎 Cara Install di iPhone/iPad (Safari):

1. **Buka website** FOODHUB UNIDA di **Safari** browser (harus Safari!)
2. Tap tombol **Share** (kotak dengan panah ke atas) di bawah layar
3. Scroll ke bawah dan tap **"Add to Home Screen"**
4. Edit nama jika perlu, lalu tap **"Add"** di pojok kanan atas
5. ✅ Selesai! Icon aplikasi akan muncul di home screen

> ⚠️ **Penting**: Di iPhone/iPad, install hanya bisa dilakukan via Safari browser, bukan Chrome atau browser lain.

---

## 💻 Cara Install di Desktop (Windows/Mac/Linux):

### Google Chrome:
1. Buka website FOODHUB UNIDA
2. Klik **icon install** (➕) di address bar, atau
3. Klik menu **⋮** → **"Install FOODHUB UNIDA"**
4. Klik **"Install"**

### Microsoft Edge:
1. Buka website FOODHUB UNIDA
2. Klik **icon install** (➕) di address bar
3. Klik **"Install"**

---

## 🚀 Setelah Install:

- Aplikasi akan muncul di **home screen** atau **app drawer** Anda
- Tap icon untuk membuka aplikasi
- Aplikasi akan buka dalam **mode standalone** (full screen tanpa browser bar)
- Semua fitur berfungsi sama seperti di browser

---

## 🗑️ Cara Uninstall:

### Android:
1. Long press icon aplikasi di home screen
2. Pilih **"Uninstall"** atau drag ke **"Remove"**

### iPhone/iPad:
1. Long press icon aplikasi
2. Tap **"Remove App"** → **"Delete App"**

### Desktop:
1. Chrome: Settings → Apps → FOODHUB UNIDA → Uninstall
2. Atau: Klik menu di aplikasi → Uninstall

---

## ❓ Troubleshooting:

**Banner install tidak muncul?**
- Pastikan Anda menggunakan browser yang didukung (Chrome/Edge/Safari)
- Pastikan Anda belum pernah dismiss banner sebelumnya
- Coba clear cache dan reload halaman
- Gunakan cara manual install

**Aplikasi tidak bisa dibuka?**
- Pastikan ada koneksi internet
- Coba uninstall dan install ulang
- Clear cache browser sebelum install

**Icon aplikasi tidak muncul?**
- Tunggu beberapa detik, proses install mungkin masih berjalan
- Restart device
- Coba install ulang

---

## 📞 Butuh Bantuan?

Jika mengalami kesulitan dalam proses install, silakan hubungi tim support FOODHUB UNIDA.

---

**Selamat menggunakan FOODHUB UNIDA! 🍔🍕🍰**
