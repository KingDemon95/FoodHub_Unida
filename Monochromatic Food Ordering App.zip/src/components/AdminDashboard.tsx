import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import {
  Receipt,
  Calendar,
  Clock,
  Users,
  Phone,
  User,
  FileText,
  CheckCircle,
  XCircle,
  LogOut,
  Loader2,
  Bell,
  Filter,
} from "lucide-react";
import { getAllInvoices, updateInvoiceStatus as updateStatus } from "../utils/dummyStorage";
import { toast } from "sonner@2.0.3";

interface AdminDashboardProps {
  user: any;
  accessToken: string;
  onLogout: () => void;
}

export function AdminDashboard({ user, accessToken, onLogout }: AdminDashboardProps) {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "pending" | "completed">("all");
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);

  const fetchInvoices = () => {
    try {
      const allInvoices = getAllInvoices();
      setInvoices(allInvoices);
    } catch (error) {
      console.error("Error fetching invoices:", error);
      toast.error("Terjadi kesalahan saat mengambil data invoice");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchInvoices();

    // Poll for new invoices every 10 seconds
    const interval = setInterval(fetchInvoices, 10000);
    return () => clearInterval(interval);
  }, []);

  const updateInvoiceStatus = (invoiceId: string, status: "pending" | "completed") => {
    try {
      const success = updateStatus(invoiceId, status);
      
      if (!success) {
        toast.error("Gagal mengubah status invoice");
        return;
      }

      toast.success(`Invoice ${status === "completed" ? "diselesaikan" : "dikembalikan ke pending"}!`);
      fetchInvoices();
    } catch (error) {
      console.error("Error updating invoice status:", error);
      toast.error("Terjadi kesalahan saat mengubah status invoice");
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("id-ID", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString("id-ID", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const filteredInvoices = invoices.filter((invoice) => {
    if (filter === "all") return true;
    return invoice.status === filter;
  });

  const pendingCount = invoices.filter((inv) => inv.status === "pending").length;
  const completedCount = invoices.filter((inv) => inv.status === "completed").length;

  // Get unique booking dates for calendar view
  const bookingDates = invoices.map((inv) => ({
    date: inv.date,
    biroName: inv.biroName,
    guests: inv.guests,
    time: inv.time,
    status: inv.status,
  }));

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-white mb-2">Admin Dashboard</h1>
            <p className="text-gray-400">FOODHUB UNIDA - {user.name}</p>
          </div>
          <Button
            onClick={onLogout}
            variant="outline"
            className="border-gray-700 bg-gray-800/50 text-white hover:bg-gray-700"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Stats Cards */}
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="border-gray-700 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400">Total Invoice</p>
                    <p className="text-white mt-2">{invoices.length}</p>
                  </div>
                  <Receipt className="h-8 w-8 text-white" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="border-yellow-700 bg-yellow-900/20 backdrop-blur-sm">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400">Pending</p>
                    <p className="text-white mt-2">{pendingCount}</p>
                  </div>
                  <Bell className="h-8 w-8 text-yellow-500 animate-pulse" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="border-green-700 bg-green-900/20 backdrop-blur-sm">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400">Completed</p>
                    <p className="text-white mt-2">{completedCount}</p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Invoice List */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="border-gray-700 bg-gray-900/50 backdrop-blur-sm">
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <CardTitle className="text-white">Daftar Invoice</CardTitle>
                <div className="flex gap-2">
                  <Button
                    onClick={() => setFilter("all")}
                    variant={filter === "all" ? "default" : "outline"}
                    size="sm"
                    className={
                      filter === "all"
                        ? "bg-white text-black"
                        : "border-gray-700 bg-gray-800/50 text-white hover:bg-gray-700"
                    }
                  >
                    Semua
                  </Button>
                  <Button
                    onClick={() => setFilter("pending")}
                    variant={filter === "pending" ? "default" : "outline"}
                    size="sm"
                    className={
                      filter === "pending"
                        ? "bg-white text-black"
                        : "border-gray-700 bg-gray-800/50 text-white hover:bg-gray-700"
                    }
                  >
                    Pending
                  </Button>
                  <Button
                    onClick={() => setFilter("completed")}
                    variant={filter === "completed" ? "default" : "outline"}
                    size="sm"
                    className={
                      filter === "completed"
                        ? "bg-white text-black"
                        : "border-gray-700 bg-gray-800/50 text-white hover:bg-gray-700"
                    }
                  >
                    Completed
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-white" />
                </div>
              ) : filteredInvoices.length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  Tidak ada invoice
                </div>
              ) : (
                <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                  <AnimatePresence mode="popLayout">
                    {filteredInvoices.map((invoice, index) => (
                      <motion.div
                        key={invoice.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ delay: index * 0.05 }}
                        className={`p-4 rounded-lg border cursor-pointer transition-all duration-300 ${
                          selectedInvoice?.id === invoice.id
                            ? "border-white bg-gray-800"
                            : "border-gray-700 bg-gray-800/50 hover:border-gray-600"
                        }`}
                        onClick={() => setSelectedInvoice(invoice)}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <p className="text-white">{invoice.id}</p>
                            <p className="text-gray-400">
                              {invoice.biroName}
                            </p>
                          </div>
                          <span
                            className={`px-3 py-1 rounded-full text-sm ${
                              invoice.status === "pending"
                                ? "bg-yellow-900/50 text-yellow-500"
                                : "bg-green-900/50 text-green-500"
                            }`}
                          >
                            {invoice.status === "pending" ? "Pending" : "Completed"}
                          </span>
                        </div>
                        <div className="text-gray-400 space-y-1">
                          <p>📅 {formatDate(invoice.date)}</p>
                          <p>⏰ {invoice.time}</p>
                          <p>💰 Rp {invoice.total.toLocaleString("id-ID")}</p>
                          <p className="text-gray-500">
                            {formatTime(invoice.createdAt)}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Invoice Detail / Calendar */}
        <div className="space-y-4">
          {/* Invoice Detail */}
          {selectedInvoice && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <Card className="border-gray-700 bg-gray-900/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Detail Invoice</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-gray-400">Invoice ID</p>
                    <p className="text-white">{selectedInvoice.id}</p>
                  </div>

                  <Separator className="bg-gray-700" />

                  <div className="space-y-2">
                    <p className="text-gray-400">Biro</p>
                    <p className="text-white">{selectedInvoice.biroName}</p>
                    <p className="text-gray-500">{selectedInvoice.biroUsaha}</p>
                  </div>

                  <Separator className="bg-gray-700" />

                  <div className="space-y-2">
                    <p className="text-gray-400">Booking Info</p>
                    <div className="space-y-1 text-gray-300">
                      <p>👤 {selectedInvoice.userName}</p>
                      <p>📱 {selectedInvoice.telegramId}</p>
                      <p>📅 {formatDate(selectedInvoice.date)}</p>
                      <p>⏰ {selectedInvoice.time}</p>
                      <p>👥 {selectedInvoice.guests} Tamu</p>
                    </div>
                    {selectedInvoice.notes && (
                      <div className="mt-3 pt-3 border-t border-gray-700">
                        <p className="text-gray-400">
                          <span className="text-white font-semibold">💬 Permintaan Khusus:</span>
                        </p>
                        <p className="text-gray-300 mt-1 italic">{selectedInvoice.notes}</p>
                      </div>
                    )}
                  </div>

                  <Separator className="bg-gray-700" />

                  <div className="space-y-2">
                    <p className="text-gray-400">Pesanan</p>
                    <div className="space-y-1">
                      {selectedInvoice.orders.map((order: any, idx: number) => (
                        <div key={idx} className="flex justify-between text-gray-300">
                          <span>
                            {order.quantity}x {order.name}
                          </span>
                          <span>Rp {(order.price * order.quantity).toLocaleString("id-ID")}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator className="bg-gray-700" />

                  <div className="flex justify-between text-white">
                    <span>Total</span>
                    <span>Rp {selectedInvoice.total.toLocaleString("id-ID")}</span>
                  </div>

                  <Separator className="bg-gray-700" />

                  {selectedInvoice.status === "pending" ? (
                    <Button
                      onClick={() => updateInvoiceStatus(selectedInvoice.id, "completed")}
                      className="w-full bg-green-600 hover:bg-green-700 text-white"
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Tandai Selesai
                    </Button>
                  ) : (
                    <Button
                      onClick={() => updateInvoiceStatus(selectedInvoice.id, "pending")}
                      variant="outline"
                      className="w-full border-gray-700 bg-gray-800/50 text-white hover:bg-gray-700"
                    >
                      <XCircle className="h-4 w-4 mr-2" />
                      Kembalikan ke Pending
                    </Button>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Calendar View */}
          <Card className="border-gray-700 bg-gray-900/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Jadwal Booking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                {bookingDates.length === 0 ? (
                  <p className="text-gray-400 text-center py-8">Belum ada booking</p>
                ) : (
                  bookingDates.map((booking, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className={`p-3 rounded-lg border ${
                        booking.status === "pending"
                          ? "border-yellow-700 bg-yellow-900/20"
                          : "border-green-700 bg-green-900/20"
                      }`}
                    >
                      <p className="text-white">{formatDate(booking.date)}</p>
                      <p className="text-gray-400">{booking.time}</p>
                      <p className="text-gray-300">
                        {booking.biroName} - {booking.guests} tamu
                      </p>
                    </motion.div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
