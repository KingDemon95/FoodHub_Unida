import { useEffect } from 'react';

export function useGenerateIcons() {
  useEffect(() => {
    const generateIcon = async (size: number): Promise<string> => {
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d')!;

      // Background - Dark theme
      ctx.fillStyle = '#111827';
      ctx.fillRect(0, 0, size, size);

      // Add gradient overlay
      const gradient = ctx.createRadialGradient(size/2, size/2, 0, size/2, size/2, size/2);
      gradient.addColorStop(0, 'rgba(59, 130, 246, 0.1)');
      gradient.addColorStop(1, 'rgba(0, 0, 0, 0.3)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, size, size);

      // Draw food icon (fork and knife)
      ctx.fillStyle = '#FFFFFF';
      ctx.strokeStyle = '#FFFFFF';
      
      const scale = size / 192;
      const centerX = size / 2;
      const centerY = size / 2;
      
      // Fork (left)
      const forkX = centerX - 30 * scale;
      const forkY = centerY - 20 * scale;
      const forkHeight = 60 * scale;
      const forkWidth = 8 * scale;
      
      // Fork handle
      ctx.fillRect(forkX - forkWidth/2, forkY, forkWidth, forkHeight);
      
      // Fork prongs
      const prongWidth = 3 * scale;
      const prongHeight = 20 * scale;
      ctx.fillRect(forkX - 12 * scale, forkY - prongHeight, prongWidth, prongHeight);
      ctx.fillRect(forkX - 5 * scale, forkY - prongHeight, prongWidth, prongHeight);
      ctx.fillRect(forkX + 2 * scale, forkY - prongHeight, prongWidth, prongHeight);
      ctx.fillRect(forkX + 9 * scale, forkY - prongHeight, prongWidth, prongHeight);

      // Knife (right)
      const knifeX = centerX + 30 * scale;
      const knifeY = centerY - 20 * scale;
      const knifeHeight = 60 * scale;
      const knifeWidth = 8 * scale;
      
      // Knife handle
      ctx.fillRect(knifeX - knifeWidth/2, knifeY, knifeWidth, knifeHeight);
      
      // Knife blade (triangle)
      ctx.beginPath();
      ctx.moveTo(knifeX, knifeY);
      ctx.lineTo(knifeX - 10 * scale, knifeY - 25 * scale);
      ctx.lineTo(knifeX + 10 * scale, knifeY - 25 * scale);
      ctx.closePath();
      ctx.fill();

      // Add text "FOODHUB"
      ctx.fillStyle = '#FFFFFF';
      ctx.font = `bold ${14 * scale}px Arial`;
      ctx.textAlign = 'center';
      ctx.fillText('FOODHUB', centerX, centerY + 50 * scale);
      ctx.font = `${10 * scale}px Arial`;
      ctx.fillText('UNIDA', centerX, centerY + 65 * scale);

      return canvas.toDataURL('image/png');
    };

    // Check if icons already exist in cache
    const checkAndGenerateIcons = async () => {
      try {
        // Check if icon files exist
        const icon192Response = await fetch('/icon-192.png', { method: 'HEAD' }).catch(() => null);
        const icon512Response = await fetch('/icon-512.png', { method: 'HEAD' }).catch(() => null);

        // If icons don't exist, generate them
        if (!icon192Response?.ok || !icon512Response?.ok) {
          console.log('Generating app icons...');
          
          const icon192Data = await generateIcon(192);
          const icon512Data = await generateIcon(512);

          // Store in localStorage as fallback
          localStorage.setItem('app-icon-192', icon192Data);
          localStorage.setItem('app-icon-512', icon512Data);

          // Update manifest dynamically
          const manifestLink = document.querySelector('link[rel="manifest"]') as HTMLLinkElement;
          if (manifestLink) {
            // Create dynamic manifest
            const manifest = {
              name: "FOODHUB UNIDA - Aplikasi Pemesanan Makanan",
              short_name: "FOODHUB UNIDA",
              description: "Aplikasi pemesanan makanan untuk restoran FOODHUB UNIDA",
              start_url: "/",
              display: "standalone",
              background_color: "#111827",
              theme_color: "#111827",
              orientation: "portrait",
              icons: [
                {
                  src: icon192Data,
                  sizes: "192x192",
                  type: "image/png",
                  purpose: "any maskable"
                },
                {
                  src: icon512Data,
                  sizes: "512x512",
                  type: "image/png",
                  purpose: "any maskable"
                }
              ]
            };

            const manifestBlob = new Blob([JSON.stringify(manifest)], { type: 'application/json' });
            const manifestURL = URL.createObjectURL(manifestBlob);
            manifestLink.href = manifestURL;
          }

          // Update apple touch icon
          let appleTouchIcon = document.querySelector('link[rel="apple-touch-icon"]') as HTMLLinkElement;
          if (!appleTouchIcon) {
            appleTouchIcon = document.createElement('link');
            appleTouchIcon.rel = 'apple-touch-icon';
            document.head.appendChild(appleTouchIcon);
          }
          appleTouchIcon.href = icon192Data;

          // Update favicon
          let favicon = document.querySelector('link[rel="icon"]') as HTMLLinkElement;
          if (!favicon) {
            favicon = document.createElement('link');
            favicon.rel = 'icon';
            favicon.type = 'image/png';
            document.head.appendChild(favicon);
          }
          favicon.href = icon192Data;

          console.log('App icons generated successfully!');
        }
      } catch (error) {
        console.error('Error generating icons:', error);
      }
    };

    checkAndGenerateIcons();
  }, []);
}
