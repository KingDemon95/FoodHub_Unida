# 🔧 Dokumentasi Teknis PWA - FOODHUB UNIDA

## Arsitektur PWA

Aplikasi FOODHUB UNIDA telah diimplementasikan sebagai **Progressive Web App (PWA)** dengan fitur-fitur berikut:

### 1. **Service Worker** (`/public/sw.js`)
- **Caching Strategy**: Network First, fallback to Cache
- **Offline Support**: Cache essential resources untuk offline access
- **Auto Update**: Service worker otomatis update saat ada perubahan
- **Supabase Bypass**: Request ke Supabase selalu menggunakan network (tidak di-cache)

### 2. **Web App Manifest** (`/public/manifest.json`)
- Name: "FOODHUB UNIDA - Aplikasi Pemesanan Makanan"
- Display mode: Standalone (full screen tanpa browser bar)
- Theme color: #111827 (dark theme)
- Icons: 192x192 dan 512x512 (auto-generated)
- Orientation: Portrait

### 3. **Install Prompt Component** (`/components/PWAInstallPrompt.tsx`)
- Smart banner untuk prompt install
- Support Android (Chrome/Edge) dan iOS (Safari)
- User-friendly instructions untuk iOS users
- Dismissable dengan localStorage tracking
- Auto-hide setelah install

### 4. **Icon Generator** (`/utils/useGenerateIcons.ts`)
- Auto-generate app icons on first load
- Fallback jika icon files tidak tersedia
- Dynamic manifest generation dengan data URL icons
- Stores icons di localStorage sebagai backup

---

## 📁 Struktur File PWA

```
/
├── index.html                      # Entry point dengan PWA meta tags
├── public/
│   ├── manifest.json               # Web app manifest
│   ├── sw.js                       # Service worker
│   ├── icon-192.png               # App icon 192x192 (auto-generated)
│   └── icon-512.png               # App icon 512x512 (auto-generated)
├── components/
│   └── PWAInstallPrompt.tsx       # Install banner component
├── utils/
│   ├── useGenerateIcons.ts        # Icon generator hook
│   └── iconGenerator.ts           # Icon generator utilities
└── PANDUAN_INSTALL_PWA.md         # User guide untuk install
```

---

## 🚀 Cara Kerja

### 1. **First Load**
```
User membuka website
    ↓
useGenerateIcons() hook berjalan
    ↓
Check apakah icon files exist
    ↓
Jika tidak, generate icons dengan canvas
    ↓
Store icons di localStorage
    ↓
Update manifest dengan data URL icons
    ↓
Service worker register
    ↓
Cache essential resources
```

### 2. **Install Flow (Android)**
```
beforeinstallprompt event fired
    ↓
PWAInstallPrompt component shows banner
    ↓
User tap "Install"
    ↓
Browser shows native install dialog
    ↓
User confirms
    ↓
App installed to home screen
    ↓
Banner auto-hide
```

### 3. **Install Flow (iOS)**
```
PWAInstallPrompt detects iOS
    ↓
User tap "Install"
    ↓
Shows iOS-specific instructions modal
    ↓
User follows manual steps:
  - Tap Share button in Safari
  - Tap "Add to Home Screen"
  - Tap "Add"
    ↓
App installed to home screen
```

### 4. **Offline Support**
```
User loses connection
    ↓
Fetch request fails
    ↓
Service worker intercepts
    ↓
Return cached response
    ↓
App continues working (limited functionality)
```

---

## 🔒 Security & Best Practices

### HTTPS Required
PWA requires HTTPS for security. Service Workers only work on:
- `https://` domains (production)
- `localhost` (development)

### Cache Strategy
- **Network First**: Untuk data dinamis (API calls, user data)
- **Cache First**: Untuk static assets (icons, styles)
- **Bypass Cache**: Untuk Supabase requests (selalu fresh data)

### Icon Requirements
- Minimum 192x192px dan 512x512px
- PNG format recommended
- Purpose: "any maskable" untuk support berbagai device

### Manifest Requirements
- `start_url`: "/" (root)
- `display`: "standalone" (full screen app)
- `theme_color`: Matches app design
- `background_color`: Loading screen background

---

## 🛠️ Development

### Testing PWA di Local

1. **Run development server**
   ```bash
   npm run dev
   ```

2. **Open Chrome DevTools**
   - Application tab → Service Workers
   - Check "Update on reload"
   - Check service worker status

3. **Test manifest**
   - Application tab → Manifest
   - Verify all fields correct
   - Check icons loading

4. **Test install**
   - Open site di Chrome
   - Install prompt should appear
   - Or use menu → "Install app"

### Debugging

**Service Worker Issues:**
```javascript
// In browser console
navigator.serviceWorker.getRegistrations().then(registrations => {
  registrations.forEach(registration => {
    console.log('SW:', registration);
    // registration.unregister(); // To unregister
  });
});
```

**Check Cache:**
```javascript
caches.keys().then(keys => console.log('Cache keys:', keys));
caches.open('foodhub-unida-v1').then(cache => 
  cache.keys().then(keys => console.log('Cached:', keys))
);
```

**Clear All PWA Data:**
```javascript
// Clear service workers
navigator.serviceWorker.getRegistrations()
  .then(registrations => registrations.forEach(r => r.unregister()));

// Clear caches
caches.keys().then(keys => keys.forEach(key => caches.delete(key)));

// Clear localStorage
localStorage.clear();
```

---

## 📊 PWA Audit

Use **Lighthouse** (Chrome DevTools) to audit PWA:
1. Open DevTools → Lighthouse tab
2. Select "Progressive Web App"
3. Click "Generate report"
4. Fix any issues reported

### Target Scores:
- ✅ PWA: 100/100
- ✅ Performance: 90+
- ✅ Accessibility: 90+
- ✅ Best Practices: 90+
- ✅ SEO: 90+

---

## 🔄 Update Strategy

### Service Worker Updates
Service worker auto-updates when `sw.js` changes:
```javascript
// In sw.js, increment version when updating
const CACHE_NAME = 'foodhub-unida-v2'; // v1 → v2
```

### Force Update
```javascript
// In PWAInstallPrompt.tsx or App.tsx
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js', { updateViaCache: 'none' });
}
```

### Clear Old Caches
Service worker automatically deletes old caches on activate event.

---

## 📱 Platform-Specific Notes

### Android (Chrome/Edge)
- ✅ Full PWA support
- ✅ beforeinstallprompt event
- ✅ Auto install banner
- ✅ Add to home screen
- ✅ Splash screen auto-generated

### iOS (Safari)
- ⚠️ Limited PWA support
- ❌ No beforeinstallprompt event
- ❌ No auto install banner
- ✅ Manual "Add to Home Screen"
- ⚠️ No splash screen customization
- ⚠️ No push notifications

### Desktop (Chrome/Edge)
- ✅ Full PWA support
- ✅ Install as desktop app
- ✅ Window app dengan own taskbar icon

---

## 🐛 Common Issues & Solutions

### Issue: Install banner tidak muncul
**Solution:**
- Check HTTPS/localhost
- Clear browser cache
- Check if already installed
- User might have dismissed before (check localStorage)

### Issue: Service worker tidak register
**Solution:**
- Check browser console for errors
- Verify `/sw.js` accessible
- Check HTTPS requirement
- Try unregister and re-register

### Issue: Icons tidak muncul
**Solution:**
- Check icon generator running
- Verify localStorage has icons
- Check browser console for errors
- Manually generate icons

### Issue: Cache tidak working
**Solution:**
- Check service worker activated
- Verify cache strategy in sw.js
- Clear old caches
- Increment CACHE_NAME version

---

## 📚 Resources

- [MDN: Progressive Web Apps](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps)
- [Google: PWA Checklist](https://web.dev/pwa-checklist/)
- [Web.dev: Service Workers](https://web.dev/service-workers/)
- [Can I Use: Service Workers](https://caniuse.com/serviceworkers)

---

**Last Updated:** 2026-01-05
**Version:** 1.0.0
