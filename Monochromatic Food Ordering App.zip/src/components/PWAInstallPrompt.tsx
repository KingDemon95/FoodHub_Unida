import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, X, HelpCircle } from 'lucide-react';
import { Button } from './ui/button';
import { InstallGuide } from './InstallGuide';
import { PWA_CONFIG, isPWASupported } from '../utils/pwa-config';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);
  const [showFullGuide, setShowFullGuide] = useState(false);

  useEffect(() => {
    // Check if iOS
    const iOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    setIsIOS(iOS);

    // Check if we're in Figma preview environment
    const isFigmaPreview = window.location.hostname.includes('figma');
    
    // Register service worker with delay to not interfere with initial load
    if (PWA_CONFIG.enableServiceWorker && isPWASupported() && !isFigmaPreview) {
      // Wait for page to fully load before registering SW
      const registerSW = async () => {
        try {
          console.log('[PWA] Preparing to register service worker...');
          
          // First check if sw.js is accessible
          try {
            const swCheck = await fetch('/sw.js', { method: 'HEAD' });
            if (!swCheck.ok || !swCheck.headers.get('content-type')?.includes('javascript')) {
              console.log('[PWA] Service worker file not accessible or wrong MIME type, skipping registration');
              return;
            }
          } catch (checkError) {
            console.log('[PWA] Service worker file not found, skipping registration');
            return;
          }
          
          // First, unregister any old service workers
          const registrations = await navigator.serviceWorker.getRegistrations();
          if (registrations.length > 0) {
            console.log('[PWA] Found existing service workers, cleaning up...');
            for (const registration of registrations) {
              await registration.unregister();
              console.log('[PWA] Old service worker unregistered');
            }
            
            // Clear old caches
            const cacheNames = await caches.keys();
            await Promise.all(cacheNames.map(name => caches.delete(name)));
            console.log('[PWA] Old caches cleared');
            
            // Wait a bit before re-registering
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
          
          // Register new service worker
          const registration = await navigator.serviceWorker.register('/sw.js', {
            scope: PWA_CONFIG.scope,
            updateViaCache: PWA_CONFIG.updateViaCache
          });
          
          console.log('[PWA] Service Worker registered successfully:', registration);
          
          // Update on reload
          registration.addEventListener('updatefound', () => {
            const newWorker = registration.installing;
            if (newWorker) {
              newWorker.addEventListener('statechange', () => {
                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                  console.log('[PWA] New service worker available');
                }
              });
            }
          });
        } catch (error) {
          // Silently handle service worker errors in preview environments
          if (error instanceof Error && error.name === 'SecurityError') {
            console.log('[PWA] Service Worker not available in this environment');
          } else {
            console.warn('[PWA] Service Worker registration failed:', error);
          }
          // Don't show error to user, PWA features just won't be available
        }
      };

      // Only register SW after page is fully loaded and after a delay
      const initSW = () => {
        setTimeout(registerSW, PWA_CONFIG.registrationDelay);
      };

      if (document.readyState === 'complete') {
        initSW();
      } else {
        window.addEventListener('load', initSW);
      }
    } else {
      if (isFigmaPreview) {
        console.log('[PWA] Service Worker disabled in Figma preview environment');
      } else {
        console.log('[PWA] Service Worker disabled or not supported');
      }
    }

    // Listen for install prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      
      // Check if user has dismissed before
      const dismissed = localStorage.getItem('pwa-prompt-dismissed');
      if (!dismissed) {
        setShowPrompt(true);
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setShowPrompt(false);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) {
      if (isIOS) {
        setShowIOSInstructions(true);
      }
      return;
    }

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      console.log('User accepted the install prompt');
    }
    
    setDeferredPrompt(null);
    setShowPrompt(false);
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem('pwa-prompt-dismissed', 'true');
  };

  const handleIOSDismiss = () => {
    setShowIOSInstructions(false);
    setShowPrompt(false);
  };

  const handleFullGuideDismiss = () => {
    setShowFullGuide(false);
    setShowPrompt(false);
  };

  // iOS Instructions Modal
  if (showIOSInstructions) {
    return (
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={handleIOSDismiss}
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="bg-gray-900 border border-gray-700 rounded-lg p-6 max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl text-white">Install FOODHUB UNIDA</h3>
              <button
                onClick={handleIOSDismiss}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="space-y-4 text-gray-300">
              <p>Untuk install aplikasi di iOS/iPhone:</p>
              <ol className="list-decimal list-inside space-y-2 text-sm">
                <li>Tap tombol <strong>Share</strong> (kotak dengan panah ke atas) di Safari</li>
                <li>Scroll ke bawah dan tap <strong>"Add to Home Screen"</strong></li>
                <li>Tap <strong>"Add"</strong> di pojok kanan atas</li>
              </ol>
              <p className="text-xs text-gray-400">
                * Pastikan Anda membuka website ini di Safari browser
              </p>
            </div>

            <Button
              onClick={handleIOSDismiss}
              className="w-full mt-6 bg-white text-black hover:bg-gray-200"
            >
              Mengerti
            </Button>
          </motion.div>
        </motion.div>
      </AnimatePresence>
    );
  }

  // Full Guide Modal
  if (showFullGuide) {
    return (
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={handleFullGuideDismiss}
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="bg-gray-900 border border-gray-700 rounded-lg p-6 max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl text-white">Install FOODHUB UNIDA</h3>
              <button
                onClick={handleFullGuideDismiss}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <InstallGuide />

            <Button
              onClick={handleFullGuideDismiss}
              className="w-full mt-6 bg-white text-black hover:bg-gray-200"
            >
              Mengerti
            </Button>
          </motion.div>
        </motion.div>
      </AnimatePresence>
    );
  }

  // Regular Install Prompt
  if (!showPrompt) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:max-w-md z-50"
      >
        <div className="bg-gray-900 border border-gray-700 rounded-lg shadow-2xl p-4">
          <div className="flex items-start gap-3">
            <div className="bg-white text-black p-2 rounded-lg">
              <Download className="h-5 w-5" />
            </div>
            
            <div className="flex-1">
              <h4 className="text-white font-semibold mb-1">
                Install FOODHUB UNIDA
              </h4>
              <p className="text-sm text-gray-400 mb-3">
                Install aplikasi untuk akses lebih cepat dan mudah di perangkat Anda
              </p>
              
              <div className="flex gap-2">
                <Button
                  onClick={handleInstallClick}
                  size="sm"
                  className="bg-white text-black hover:bg-gray-200"
                >
                  Install
                </Button>
                <Button
                  onClick={handleDismiss}
                  size="sm"
                  variant="outline"
                  className="border-gray-700 text-gray-300 hover:bg-gray-800"
                >
                  Nanti
                </Button>
                <Button
                  onClick={() => setShowFullGuide(true)}
                  size="sm"
                  variant="outline"
                  className="border-gray-700 text-gray-300 hover:bg-gray-800"
                >
                  <HelpCircle className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <button
              onClick={handleDismiss}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}