import { useState } from 'react';
import { motion } from 'motion/react';
import { Download } from 'lucide-react';
import { InstallGuide } from './InstallGuide';

export function InstallButton() {
  const [showGuide, setShowGuide] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);

  // Check if app is already installed
  useState(() => {
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }
  });

  // Don't show button if already installed
  if (isInstalled) return null;

  return (
    <>
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 2, type: 'spring', stiffness: 200 }}
        onClick={() => setShowGuide(true)}
        className="fixed bottom-6 right-6 z-40 bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-full shadow-2xl flex items-center gap-2 group transition-all"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Download className="h-6 w-6" />
        <motion.span
          initial={{ width: 0, opacity: 0 }}
          whileHover={{ width: 'auto', opacity: 1 }}
          className="overflow-hidden whitespace-nowrap pr-2"
        >
          Download App
        </motion.span>
      </motion.button>

      {showGuide && <InstallGuide onClose={() => setShowGuide(false)} />}
    </>
  );
}
