// Service Worker Helper Functions

/**
 * Unregister all service workers (use this if SW is causing issues)
 */
export async function unregisterServiceWorkers() {
  if ('serviceWorker' in navigator) {
    try {
      const registrations = await navigator.serviceWorker.getRegistrations();
      for (const registration of registrations) {
        await registration.unregister();
        console.log('Service Worker unregistered:', registration);
      }
      // Clear all caches
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.map(name => caches.delete(name)));
      console.log('All caches cleared');
      return true;
    } catch (error) {
      console.error('Error unregistering service workers:', error);
      return false;
    }
  }
  return false;
}

/**
 * Check if service worker is active
 */
export function isServiceWorkerActive(): boolean {
  if ('serviceWorker' in navigator) {
    return navigator.serviceWorker.controller !== null;
  }
  return false;
}

/**
 * Clear all service worker caches
 */
export async function clearServiceWorkerCaches() {
  try {
    const cacheNames = await caches.keys();
    await Promise.all(cacheNames.map(name => caches.delete(name)));
    console.log('Service worker caches cleared');
    return true;
  } catch (error) {
    console.error('Error clearing caches:', error);
    return false;
  }
}

/**
 * Update service worker
 */
export async function updateServiceWorker() {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      if (registration) {
        await registration.update();
        console.log('Service worker updated');
        return true;
      }
    } catch (error) {
      console.error('Error updating service worker:', error);
    }
  }
  return false;
}
