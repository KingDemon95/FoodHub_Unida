# 🔧 TROUBLESHOOTING - FOODHUB UNIDA

## ⚠️ Masalah Login: "Failed to fetch" atau "Network Error"

### Penyebab:
Service Worker (PWA) mungkin mengintervensi koneksi ke server.

### Solusi:

#### **Cara 1: Clear Cache via Aplikasi (Termudah)**
1. Di halaman **Login**, scroll ke bawah
2. Klik tombol kecil: **"Bermasalah login? Clear Cache & Reload"**
3. Tunggu aplikasi reload otomatis
4. Coba login lagi ✅

#### **Cara 2: Clear Cache via Browser**

**Chrome/Edge (Desktop):**
1. Tekan `Ctrl+Shift+Delete` (Windows) atau `Cmd+Shift+Delete` (Mac)
2. Pilih **"All time"**
3. Centang: **Cached images and files** dan **Site settings**
4. Klik **Clear data**
5. Refresh halaman (F5)

**Chrome (Android):**
1. Buka **Settings** > **Privacy and security** > **Clear browsing data**
2. Pilih **All time**
3. Centang: **Cached images and files** dan **Cookies and site data**
4. Tap **Clear data**
5. Buka aplikasi lagi

**Safari (iOS):**
1. Buka **Settings** > **Safari**
2. Tap **Clear History and Website Data**
3. Konfirmasi **Clear History and Data**
4. Buka Safari dan akses aplikasi lagi

#### **Cara 3: Hard Refresh**
- **Chrome/Edge:** `Ctrl+Shift+R` (Windows) atau `Cmd+Shift+R` (Mac)
- **Firefox:** `Ctrl+F5`
- **Safari:** `Cmd+Option+R`

#### **Cara 4: Unregister Service Worker Manual**

1. Buka **DevTools** (F12)
2. Pilih tab **Application** (Chrome/Edge) atau **Storage** (Firefox)
3. Klik **Service Workers** di sidebar
4. Klik **Unregister** untuk semua service workers
5. Klik **Clear storage** > **Clear site data**
6. Refresh halaman

---

## 🔄 Service Worker Sudah Diperbaiki

**Versi terbaru aplikasi sudah menggunakan Service Worker yang:**
- ✅ Tidak mengintervensi API calls ke Supabase
- ✅ Tidak mengintervensi authentication requests
- ✅ Hanya cache static assets (gambar, icons)
- ✅ Menggunakan network-first strategy
- ✅ Auto-unregister old service workers

**Service Worker akan:**
- Register setelah 3 detik page load (tidak mengganggu initial load)
- Membersihkan old service workers otomatis
- Hanya cache file static seperti icons dan images

---

## 📱 Masalah Install PWA

### "Install button tidak muncul"

**Android:**
- Pastikan menggunakan **Chrome** atau **Edge** (bukan browser lain)
- Refresh halaman
- Gunakan cara manual: **⋮ Menu** > **"Install app"**

**iPhone/iPad:**
- PWA di iOS **tidak ada install prompt otomatis**
- Harus pakai cara manual via Safari Share button
- Lihat tutorial lengkap: Klik tombol **"Download App"** di aplikasi

**Desktop:**
- Pastikan menggunakan **Chrome** atau **Edge**
- Cek address bar, ada icon install **➕** atau **⬇**
- Jika tidak ada, coba refresh halaman

### "Sudah install tapi icon tidak muncul"

**Android:**
- Cek di **App Drawer** (list semua aplikasi)
- Restart HP
- Install ulang

**iPhone/iPad:**
- Cek semua home screen pages
- Gunakan search (swipe down di home screen)
- Install ulang via Safari

---

## 🚫 Cara Uninstall PWA

**Android:**
1. Tekan dan tahan icon **FOODHUB UNIDA**
2. Pilih **Uninstall** atau **Remove**

**iPhone/iPad:**
1. Tekan dan tahan icon **FOODHUB UNIDA**
2. Tap **Remove App**
3. Pilih **Delete App**

**Desktop (Chrome/Edge):**
1. Buka aplikasi FOODHUB UNIDA
2. Klik **⋮ Menu** (3 titik) di pojok kanan atas
3. Pilih **Uninstall FOODHUB UNIDA**

---

## 🌐 Masalah Koneksi Internet

### "Offline - Please check your internet connection"

1. Pastikan HP/komputer tersambung ke internet
2. Coba buka website lain untuk test koneksi
3. Restart router WiFi
4. Ganti ke mobile data atau WiFi lain
5. Clear cache dan reload

---

## 🔐 Masalah Login/Authentication

### "Login gagal - tidak ada sesi"
- Cek email dan password sudah benar
- Clear cache (lihat Cara 1 di atas)
- Coba browser lain (Chrome, Firefox, Safari)

### "Gagal mengambil data user"
- Koneksi internet tidak stabil
- Server mungkin sedang maintenance
- Clear cache dan coba lagi dalam beberapa menit

### "Email already registered"
- Email sudah terdaftar sebelumnya
- Gunakan tombol **Login** bukan **Daftar**
- Atau gunakan email lain

---

## 🆘 Masih Bermasalah?

### Quick Fix Lengkap:
```
1. Clear cache via tombol di halaman login
2. Hard refresh (Ctrl+Shift+R)
3. Logout dan login ulang
4. Restart browser
5. Restart HP/komputer
```

### Emergency: Disable PWA Completely
Jika PWA terus menyebabkan masalah, buka aplikasi via browser biasa tanpa install:
1. Uninstall aplikasi PWA
2. Buka via browser (Chrome/Safari)
3. Gunakan dalam browser tanpa install
4. Semua fitur tetap berfungsi normal ✅

---

## ⚙️ Developer Mode: Disable Service Worker

Jika Anda developer dan ingin disable Service Worker:

1. Edit `/utils/pwa-config.ts`
2. Set `enableServiceWorker: false`
3. Save dan reload aplikasi

---

## 📞 Kontak Support

Jika masalah masih berlanjut setelah mencoba semua solusi di atas, hubungi admin FOODHUB UNIDA.

**Tips:** Screenshot error message dan browser console (F12) untuk mempercepat troubleshooting.

---

**Terakhir diupdate:** Januari 2025  
**Version:** PWA v2 (Service Worker sudah diperbaiki)
