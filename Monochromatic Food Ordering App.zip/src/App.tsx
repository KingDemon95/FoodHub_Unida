import { useState, useEffect } from "react";
import { Login } from "./components/Login";
import { SetupAdmin } from "./components/SetupAdmin";
import { AdminDashboard } from "./components/AdminDashboard";
import { BiroDashboard } from "./components/BiroDashboard";
import { PWAInstallPrompt } from "./components/PWAInstallPrompt";
import { InstallButton } from "./components/InstallButton";
import { Toaster } from "./components/ui/sonner";
import { Loader2 } from "lucide-react";
import { getDummySession, dummyLogout } from "./utils/dummyAuth";
import { initializeDummyData } from "./utils/dummyStorage";
import { useGenerateIcons } from "./utils/useGenerateIcons";

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showSetupAdmin, setShowSetupAdmin] = useState(false);
  
  // Generate PWA icons on first load
  useGenerateIcons();

  // Check for existing session on mount
  useEffect(() => {
    const checkSession = () => {
      try {
        // Initialize dummy data for invoices
        initializeDummyData();

        const session = getDummySession();

        if (session) {
          setUser(session.user);
          setAccessToken(session.accessToken);
        }
      } catch (error) {
        console.error("Error checking session:", error);
      } finally {
        setIsLoading(false);
      }
    };

    checkSession();
  }, []);

  const handleLoginSuccess = (userData: any, token: string) => {
    setUser(userData);
    setAccessToken(token);
    setShowSetupAdmin(false);
  };

  const handleLogout = () => {
    dummyLogout();
    setUser(null);
    setAccessToken(null);
  };

  const handleSetupAdminComplete = () => {
    setShowSetupAdmin(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-white" />
      </div>
    );
  }

  if (showSetupAdmin) {
    return (
      <>
        <SetupAdmin onComplete={handleSetupAdminComplete} />
        <Toaster position="top-center" />
      </>
    );
  }

  if (!user || !accessToken) {
    return (
      <>
        <Login 
          onLoginSuccess={handleLoginSuccess} 
          onSetupAdmin={() => setShowSetupAdmin(true)}
        />
        <Toaster position="top-center" />
      </>
    );
  }

  return (
    <>
      {user.role === "admin" ? (
        <AdminDashboard user={user} accessToken={accessToken} onLogout={handleLogout} />
      ) : (
        <BiroDashboard user={user} accessToken={accessToken} onLogout={handleLogout} />
      )}
      <PWAInstallPrompt />
      <InstallButton />
      <Toaster position="top-center" />
    </>
  );
}