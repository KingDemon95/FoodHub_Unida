# Dummy Authentication System

Aplikasi FOODHUB UNIDA sekarang menggunakan **Dummy Authentication System** yang tidak memerlukan koneksi ke Supabase. Semua data disimpan di **localStorage** browser.

## 🔑 Akun Dummy yang Tersedia

### Admin
- **Email:** admin@foodhub.com
- **Password:** foodhub
- **Akses:** Dashboard admin lengkap dengan semua invoice dari semua biro

### Biro Users

1. **Biro TI (Saintek)**
   - Email: ti@foodhub.com
   - Password: saintek

2. **Biro Akademik**
   - Email: akademik@foodhub.com
   - Password: akademik123

3. **Biro Kemahasiswaan**
   - Email: kemahasiswaan@foodhub.com
   - Password: mawa123

## 📊 Data Dummy

Aplikasi sudah dilengkapi dengan **5 invoice dummy** untuk testing:
- 3 invoice dengan status "pending"
- 2 invoice dengan status "completed"
- Invoice dari berbagai biro (TI, Akademik, Kemahasiswaan)

## ✨ Fitur yang Berfungsi

### Untuk Biro Users:
✅ Login dengan akun biro
✅ Membuat booking baru
✅ Memilih menu makanan
✅ Generate invoice
✅ Melihat invoice yang dibuat

### Untuk Admin:
✅ Login dengan akun admin
✅ Melihat semua invoice dari semua biro
✅ Filter invoice (All, Pending, Completed)
✅ Update status invoice (Pending ↔ Completed)
✅ Notifikasi real-time untuk invoice baru
✅ Kalender booking otomatis

## 🔧 Cara Kerja

### Authentication
- File: `/utils/dummyAuth.ts`
- Login mengecek email & password dengan array DUMMY_USERS
- Session disimpan di localStorage dengan key `foodhub_dummy_session`
- Token dummy di-generate untuk setiap session
- Session berlaku selama 24 jam

### Storage Invoice
- File: `/utils/dummyStorage.ts`
- Semua invoice disimpan di localStorage dengan key `foodhub_invoices`
- Support operasi: Create, Read, Update Status, Delete
- Auto-initialize dengan 5 dummy invoice saat pertama kali load

## 🚀 Signup Biro Baru

Biro baru **bisa mendaftar** melalui form signup, namun:
- Data hanya tersimpan di memory (array DUMMY_USERS)
- **Data akan hilang saat refresh halaman**
- Untuk testing permanent, gunakan akun dummy yang sudah tersedia

## 💾 Persistensi Data

### Data yang Persisten (tersimpan di localStorage):
- ✅ Session login
- ✅ Invoice yang dibuat
- ✅ Status invoice

### Data yang Tidak Persisten (hilang saat refresh):
- ❌ User baru hasil signup

## 🔄 Reset Data

Untuk reset semua data dummy:
1. Buka browser console (F12)
2. Jalankan: `localStorage.clear()`
3. Refresh halaman

Atau hapus item spesifik:
- Session: `localStorage.removeItem('foodhub_dummy_session')`
- Invoices: `localStorage.removeItem('foodhub_invoices')`

## 📝 Catatan Penting

1. **Tidak ada koneksi ke server/database**
   - Semua data lokal di browser
   - Data berbeda di setiap browser/device

2. **Data invoice persisten**
   - Invoice yang dibuat akan tetap ada meskipun logout
   - Invoice bisa dilihat oleh admin dari semua biro

3. **Mode PWA tetap berfungsi**
   - Aplikasi bisa di-install sebagai PWA
   - Service worker hanya cache static assets
   - Tidak ada API calls yang di-block

## 🎯 Use Case

Sistem dummy ini cocok untuk:
- ✅ Testing & development
- ✅ Demo aplikasi
- ✅ Prototyping
- ✅ Offline-first testing
- ❌ Production use (gunakan Supabase untuk production)

## 🔗 File-file Terkait

- `/utils/dummyAuth.ts` - Authentication logic
- `/utils/dummyStorage.ts` - Invoice storage logic
- `/components/Login.tsx` - Login UI dengan dummy credentials
- `/App.tsx` - Session check & initialization
- `/components/BiroDashboard.tsx` - Create invoice
- `/components/AdminDashboard.tsx` - View & manage invoices
