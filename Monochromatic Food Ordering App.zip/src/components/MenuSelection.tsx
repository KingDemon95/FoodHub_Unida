import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Minus, Plus, ShoppingCart, ChevronRight, Home } from "lucide-react";

interface MenuNode {
  id: string;
  name: string;
  type: 'category' | 'item';
  price?: number;
  children?: MenuNode[];
}

interface MenuSelectionProps {
  onComplete: (orders: OrderItem[]) => void;
  onBack: () => void;
}

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

const menuStructure: MenuNode[] = [
  {
    id: "madamat",
    name: "Madamat",
    type: "category",
    children: [
      {
        id: "madamat-asif",
        name: "Ustadz Asif",
        type: "category",
        children: [
          {
            id: "madamat-asif-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-asif-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-asif-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-asif-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-asif-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-cecep",
        name: "Ustadz Cecep",
        type: "category",
        children: [
          {
            id: "madamat-cecep-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-cecep-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-cecep-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-cecep-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-cecep-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-nurhadi",
        name: "Ustadz Nur Hadi",
        type: "category",
        children: [
          {
            id: "madamat-nurhadi-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-nurhadi-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-nurhadi-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-nurhadi-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-nurhadi-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-fairuz",
        name: "Ustadz Fairuz",
        type: "category",
        children: [
          {
            id: "madamat-fairuz-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-fairuz-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-fairuz-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-fairuz-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-fairuz-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-suyanto",
        name: "Ustadz Suyanto",
        type: "category",
        children: [
          {
            id: "madamat-suyanto-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-suyanto-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-suyanto-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-suyanto-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-suyanto-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-setyono",
        name: "Ustadz Setyono",
        type: "category",
        children: [
          {
            id: "madamat-setyono-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-setyono-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-setyono-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-setyono-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-setyono-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-abudarda",
        name: "Ustadz Abu Darda",
        type: "category",
        children: [
          {
            id: "madamat-abudarda-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-abudarda-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-abudarda-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-abudarda-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-abudarda-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-hilmi",
        name: "Ustadz Hilmi",
        type: "category",
        children: [
          {
            id: "madamat-hilmi-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-hilmi-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-hilmi-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-hilmi-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-hilmi-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-andi",
        name: "Ustadz Andi",
        type: "category",
        children: [
          {
            id: "madamat-andi-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-andi-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-andi-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-andi-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-andi-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-rizqon",
        name: "Ustadz Rizqon",
        type: "category",
        children: [
          {
            id: "madamat-rizqon-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-rizqon-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-rizqon-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-rizqon-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-rizqon-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-eli",
        name: "Ustadz Eli",
        type: "category",
        children: [
          {
            id: "madamat-eli-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-eli-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-eli-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-eli-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-eli-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
      {
        id: "madamat-huda",
        name: "Ustadz Huda",
        type: "category",
        children: [
          {
            id: "madamat-huda-nasi",
            name: "Nasi (15.000)",
            type: "category",
            children: [
              { id: "madamat-huda-nasi-ikan", name: "Ikan", type: "item", price: 15000 },
              { id: "madamat-huda-nasi-ayam", name: "Ayam", type: "item", price: 15000 },
              { id: "madamat-huda-nasi-telur", name: "Telur", type: "item", price: 15000 },
            ],
          },
          { id: "madamat-huda-gorengan", name: "Gorengan (setiap madamat memiliki jenis berbeda)", type: "item", price: 2500 },
        ],
      },
    ],
  },
  {
    id: "buah",
    name: "Buah",
    type: "category",
    children: [
      { id: "buah-anggur", name: "Anggur", type: "item", price: 80000 },
      { id: "buah-semangka", name: "Semangka", type: "item", price: 15000 },
      { id: "buah-melon", name: "Melon", type: "item", price: 25000 },
      { id: "buah-jeruk", name: "Jeruk", type: "item", price: 30000 },
      { id: "buah-kelengkeng", name: "Kelengkeng", type: "item", price: 80000 },
      { id: "buah-salak", name: "Salak", type: "item", price: 20000 },
      { id: "buah-pisang", name: "Pisang", type: "item", price: 25000 },
      { id: "buah-apel", name: "Apel", type: "item", price: 40000 },
    ],
  },
  {
    id: "bakkery",
    name: "Bakkery",
    type: "category",
    children: [
      { id: "bakkery-kejudalam", name: "Keju dalam", type: "item", price: 7000 },
      { id: "bakkery-coklatdalam", name: "Coklat dalam", type: "item", price: 7000 },
      { id: "bakkery-sosislilit", name: "Sosis lilit", type: "item", price: 7000 },
      { id: "bakkery-pizza", name: "Pizza", type: "item", price: 7000 },
      { id: "bakkery-rotio", name: "Roti O", type: "item", price: 7000 },
      { id: "bakkery-croissant", name: "Croissant", type: "item", price: 7000 },
      { id: "bakkery-klappertaart", name: "Klappertaart", type: "item", price: 7000 },
      { id: "bakkery-gunungmeletus", name: "Gunung meletus", type: "item", price: 7000 },
      { id: "bakkery-rotibungacoklat", name: "Roti bunga coklat", type: "item", price: 7000 },
      { id: "bakkery-donut", name: "Donut", type: "item", price: 7000 },
      { id: "bakkery-piscok", name: "Piscok", type: "item", price: 7000 },
      { id: "bakkery-kukusbungamekar", name: "Kukus bunga mekar", type: "item", price: 7000 },
    ],
  },
  {
    id: "beverage",
    name: "Beverage",
    type: "category",
    children: [
      { id: "beverage-teh", name: "Teh", type: "item", price: 7000 },
      { id: "beverage-jusjambu", name: "Jus Jambu", type: "item", price: 7000 },
      { id: "beverage-jusmangga", name: "Jus Mangga", type: "item", price: 7000 },
      { id: "beverage-jusalpukat", name: "Jus Alpukat", type: "item", price: 7000 },
      { id: "beverage-jusjeruk", name: "Jus Jeruk", type: "item", price: 7000 },
      { id: "beverage-capcin", name: "Capcin", type: "item", price: 7000 },
      { id: "beverage-minumanjelly", name: "Minuman Jelly", type: "item", price: 7000 },
      { id: "beverage-cheesemilk", name: "Cheese Milk", type: "item", price: 7000 },
      { id: "beverage-kopi", name: "Kopi", type: "item", price: 7000 },
      { id: "beverage-rosela", name: "Rosela", type: "item", price: 7000 },
      { id: "beverage-talang", name: "Talang", type: "item", price: 7000 },
      { id: "beverage-lemontea", name: "Lemon Tea", type: "item", price: 7000 },
    ],
  },
];

export function MenuSelection({ onComplete, onBack }: MenuSelectionProps) {
  const [orders, setOrders] = useState<Map<string, OrderItem>>(new Map());
  const [currentPath, setCurrentPath] = useState<MenuNode[]>([]);

  const getCurrentItems = (): MenuNode[] => {
    if (currentPath.length === 0) {
      return menuStructure;
    }
    const lastNode = currentPath[currentPath.length - 1];
    return lastNode.children || [];
  };

  const navigateToNode = (node: MenuNode) => {
    if (node.type === 'category') {
      setCurrentPath([...currentPath, node]);
    } else {
      // It's an item, add to cart
      addItem(node);
    }
  };

  const navigateBack = () => {
    setCurrentPath(currentPath.slice(0, -1));
  };

  const navigateToRoot = () => {
    setCurrentPath([]);
  };

  const addItem = (item: MenuNode) => {
    if (item.type !== 'item' || !item.price) return;
    
    setOrders((prev) => {
      const newOrders = new Map(prev);
      const existing = newOrders.get(item.id);
      if (existing) {
        newOrders.set(item.id, { ...existing, quantity: existing.quantity + 1 });
      } else {
        newOrders.set(item.id, {
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: 1,
        });
      }
      return newOrders;
    });
  };

  const removeItem = (itemId: string) => {
    setOrders((prev) => {
      const newOrders = new Map(prev);
      const existing = newOrders.get(itemId);
      if (existing) {
        if (existing.quantity > 1) {
          newOrders.set(itemId, { ...existing, quantity: existing.quantity - 1 });
        } else {
          newOrders.delete(itemId);
        }
      }
      return newOrders;
    });
  };

  const getItemQuantity = (itemId: string) => {
    return orders.get(itemId)?.quantity || 0;
  };

  const getTotalItems = () => {
    return Array.from(orders.values()).reduce((sum, item) => sum + item.quantity, 0);
  };

  const handleSubmit = () => {
    if (orders.size > 0) {
      onComplete(Array.from(orders.values()));
    }
  };

  const currentItems = getCurrentItems();
  const isRootLevel = currentPath.length === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4, ease: "easeInOut" }}
      className="space-y-6"
    >
      <Card className="border-gray-700 bg-gray-900/50 backdrop-blur-sm shadow-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <ShoppingCart className="h-5 w-5" />
            Pilih Menu
          </CardTitle>
          <CardDescription className="text-gray-400">
            Pilih makanan dan minuman favorit Anda
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Breadcrumb Navigation */}
          {!isRootLevel && (
            <div className="flex items-center gap-2 flex-wrap mb-4 pb-4 border-b border-gray-700">
              <Button
                variant="ghost"
                size="sm"
                onClick={navigateToRoot}
                className="text-gray-400 hover:text-white hover:bg-gray-800 h-8 px-2"
              >
                <Home className="h-4 w-4" />
              </Button>
              {currentPath.map((node, index) => (
                <div key={node.id} className="flex items-center gap-2">
                  <ChevronRight className="h-4 w-4 text-gray-600" />
                  {index === currentPath.length - 1 ? (
                    <span className="text-white">{node.name}</span>
                  ) : (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setCurrentPath(currentPath.slice(0, index + 1))}
                      className="text-gray-400 hover:text-white hover:bg-gray-800 h-8 px-2"
                    >
                      {node.name}
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Menu Items Grid */}
          <div className="grid gap-4">
            <AnimatePresence mode="wait">
              {currentItems.map((item, index) => {
                const quantity = item.type === 'item' ? getItemQuantity(item.id) : 0;
                const isCategory = item.type === 'category';

                return (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05, duration: 0.3 }}
                  >
                    <div
                      className={`flex items-center justify-between p-4 rounded-lg border transition-all duration-300 ${
                        isCategory
                          ? 'border-gray-600 hover:border-gray-400 bg-gray-800/70 hover:shadow-lg cursor-pointer'
                          : 'border-gray-700 hover:border-gray-500 bg-gray-800/50 hover:shadow-md'
                      }`}
                      onClick={() => isCategory && navigateToNode(item)}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-white">{item.name}</h4>
                          {isCategory && (
                            <Badge variant="outline" className="border-gray-500 text-gray-300">
                              {item.children?.length || 0} item
                            </Badge>
                          )}
                        </div>
                        {item.type === 'item' && item.price && (
                          <p className="text-white mt-1">
                            Rp {item.price.toLocaleString("id-ID")}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-3">
                        {isCategory ? (
                          <ChevronRight className="h-5 w-5 text-gray-400" />
                        ) : (
                          <>
                            <AnimatePresence>
                              {quantity > 0 && (
                                <motion.div
                                  initial={{ opacity: 0, scale: 0.8 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  exit={{ opacity: 0, scale: 0.8 }}
                                  className="flex items-center gap-2 bg-gray-700 rounded-full px-1"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <Button
                                    type="button"
                                    size="icon"
                                    variant="ghost"
                                    onClick={() => removeItem(item.id)}
                                    className="h-8 w-8 rounded-full hover:bg-gray-600 text-white"
                                  >
                                    <Minus className="h-4 w-4" />
                                  </Button>
                                  <span className="w-8 text-center text-white">{quantity}</span>
                                  <Button
                                    type="button"
                                    size="icon"
                                    variant="ghost"
                                    onClick={() => addItem(item)}
                                    className="h-8 w-8 rounded-full hover:bg-gray-600 text-white"
                                  >
                                    <Plus className="h-4 w-4" />
                                  </Button>
                                </motion.div>
                              )}
                            </AnimatePresence>
                            {quantity === 0 && (
                              <Button
                                type="button"
                                size="sm"
                                onClick={() => addItem(item)}
                                className="bg-white text-black hover:bg-gray-200 transition-colors"
                              >
                                Tambah
                              </Button>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3">
        <Button
          type="button"
          variant="outline"
          onClick={onBack}
          className="flex-1 border-gray-700 bg-gray-800/50 text-white hover:bg-gray-700 transition-colors"
        >
          Kembali
        </Button>
        <Button
          type="button"
          onClick={handleSubmit}
          disabled={orders.size === 0}
          className="flex-1 bg-white text-black hover:bg-gray-200 transition-all duration-300 disabled:bg-gray-600 disabled:text-gray-400"
        >
          Lihat Invoice ({getTotalItems()} item)
        </Button>
      </div>
    </motion.div>
  );
}