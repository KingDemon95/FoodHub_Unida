import { motion } from "motion/react";
import { Button } from "./ui/button";
import { UtensilsCrossed, ChevronRight, Download } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useState } from "react";
import { InstallGuide } from "./InstallGuide";

interface DashboardProps {
  onBookNow: () => void;
}

export function Dashboard({ onBookNow }: DashboardProps) {
  const [showInstallGuide, setShowInstallGuide] = useState(false);

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center px-4 py-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-2xl w-full text-center"
        >
          {/* Logo Container */}
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="flex justify-center mb-8"
          >
            <div className="relative">
              <motion.div
                animate={{
                  scale: [1, 1.05, 1],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="w-40 h-40 rounded-full bg-white shadow-2xl flex items-center justify-center overflow-hidden border-4 border-gray-700"
              >
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&q=80"
                  alt="FoodHub Logo"
                  className="w-full h-full object-cover"
                />
              </motion.div>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.5, type: "spring", stiffness: 200 }}
                className="absolute -bottom-2 -right-2 bg-white text-black p-3 rounded-full shadow-lg"
              >
                <UtensilsCrossed className="h-6 w-6" />
              </motion.div>
            </div>
          </motion.div>

          {/* Restaurant Name */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="mb-6"
          >
            <h1 className="text-white mb-3 tracking-wider">
              FOODHUB UNIDA
            </h1>
            <div className="flex items-center justify-center gap-2 mb-4">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: 60 }}
                transition={{ delay: 0.6, duration: 0.5 }}
                className="h-0.5 bg-white"
              />
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.8, type: "spring" }}
                className="w-2 h-2 bg-white rounded-full"
              />
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: 60 }}
                transition={{ delay: 0.6, duration: 0.5 }}
                className="h-0.5 bg-white"
              />
            </div>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.5 }}
              className="text-gray-300 max-w-md mx-auto"
            >
              Nikmati pengalaman kuliner terbaik dengan cita rasa istimewa dan pelayanan prima
            </motion.p>
          </motion.div>

          {/* Features */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.5 }}
            className="grid grid-cols-3 gap-4 mb-8 max-w-md mx-auto"
          >
            {[
              { label: "Menu Variatif", emoji: "🍽️" },
              { label: "Kualitas Terjamin", emoji: "⭐" },
              { label: "Layanan Cepat", emoji: "⚡" },
            ].map((feature, index) => (
              <motion.div
                key={feature.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1.2 + index * 0.1, duration: 0.3 }}
                className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20"
              >
                <div className="text-2xl mb-2">{feature.emoji}</div>
                <p className="text-white">{feature.label}</p>
              </motion.div>
            ))}
          </motion.div>

          {/* Book Now Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.4, duration: 0.5 }}
          >
            <Button
              onClick={onBookNow}
              size="lg"
              className="bg-white text-black hover:bg-gray-200 transition-all duration-300 group px-8 py-6"
            >
              <span className="mr-2">Book Now</span>
              <ChevronRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </motion.div>

          {/* Footer Text */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.6, duration: 0.5 }}
            className="text-gray-400 mt-8"
          >
            Sistem Pemesanan Online
          </motion.p>
        </motion.div>
      </div>
      {showInstallGuide && <InstallGuide onClose={() => setShowInstallGuide(false)} />}
    </>
  );
}