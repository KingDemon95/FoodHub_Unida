import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Smartphone, Monitor, Download, ChevronRight, Share2, Plus, MoreVertical } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

interface InstallGuideProps {
  onClose: () => void;
}

export function InstallGuide({ onClose }: InstallGuideProps) {
  const [selectedPlatform, setSelectedPlatform] = useState<'android' | 'ios' | 'desktop' | null>(null);

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-4xl my-8"
      >
        <Card className="border-gray-700 bg-gray-900 shadow-2xl">
          <CardHeader className="border-b border-gray-700">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-white">
                <Download className="h-6 w-6" />
                Cara Download & Install FOODHUB UNIDA
              </CardTitle>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            {!selectedPlatform ? (
              <div className="space-y-6">
                <div className="bg-blue-900/20 border border-blue-700/50 rounded-lg p-4">
                  <p className="text-blue-300 text-sm">
                    ℹ️ <strong>Catatan:</strong> Aplikasi ini tidak ada di Play Store atau App Store. 
                    Anda install langsung dari website melalui browser. Gratis dan aman! ✅
                  </p>
                </div>

                <div className="text-center mb-6">
                  <h3 className="text-xl text-white mb-2">Pilih Perangkat Anda:</h3>
                  <p className="text-gray-400">Klik untuk melihat tutorial lengkap</p>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  {/* Android */}
                  <button
                    onClick={() => setSelectedPlatform('android')}
                    className="group p-6 bg-gray-800 hover:bg-gray-750 border border-gray-700 hover:border-blue-500 rounded-lg transition-all"
                  >
                    <div className="text-center space-y-3">
                      <div className="w-16 h-16 mx-auto bg-green-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Smartphone className="h-8 w-8 text-white" />
                      </div>
                      <h4 className="text-lg text-white">Android</h4>
                      <p className="text-sm text-gray-400">Chrome / Edge</p>
                      <div className="flex items-center justify-center gap-1 text-blue-400 text-sm">
                        Lihat Tutorial <ChevronRight className="h-4 w-4" />
                      </div>
                    </div>
                  </button>

                  {/* iOS */}
                  <button
                    onClick={() => setSelectedPlatform('ios')}
                    className="group p-6 bg-gray-800 hover:bg-gray-750 border border-gray-700 hover:border-blue-500 rounded-lg transition-all"
                  >
                    <div className="text-center space-y-3">
                      <div className="w-16 h-16 mx-auto bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Smartphone className="h-8 w-8 text-white" />
                      </div>
                      <h4 className="text-lg text-white">iPhone / iPad</h4>
                      <p className="text-sm text-gray-400">Safari Browser</p>
                      <div className="flex items-center justify-center gap-1 text-blue-400 text-sm">
                        Lihat Tutorial <ChevronRight className="h-4 w-4" />
                      </div>
                    </div>
                  </button>

                  {/* Desktop */}
                  <button
                    onClick={() => setSelectedPlatform('desktop')}
                    className="group p-6 bg-gray-800 hover:bg-gray-750 border border-gray-700 hover:border-blue-500 rounded-lg transition-all"
                  >
                    <div className="text-center space-y-3">
                      <div className="w-16 h-16 mx-auto bg-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Monitor className="h-8 w-8 text-white" />
                      </div>
                      <h4 className="text-lg text-white">Komputer</h4>
                      <p className="text-sm text-gray-400">Chrome / Edge</p>
                      <div className="flex items-center justify-center gap-1 text-blue-400 text-sm">
                        Lihat Tutorial <ChevronRight className="h-4 w-4" />
                      </div>
                    </div>
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Back Button */}
                <button
                  onClick={() => setSelectedPlatform(null)}
                  className="text-blue-400 hover:text-blue-300 flex items-center gap-2 mb-4"
                >
                  ← Kembali ke Pilihan Platform
                </button>

                {/* Android Tutorial */}
                {selectedPlatform === 'android' && (
                  <div className="space-y-6">
                    <div className="text-center mb-6">
                      <div className="w-20 h-20 mx-auto bg-green-600 rounded-full flex items-center justify-center mb-4">
                        <Smartphone className="h-10 w-10 text-white" />
                      </div>
                      <h3 className="text-2xl text-white mb-2">Cara Install di Android</h3>
                      <p className="text-gray-400">Chrome atau Edge Browser</p>
                    </div>

                    <div className="bg-green-900/20 border border-green-700/50 rounded-lg p-4 mb-6">
                      <p className="text-green-300 text-sm">
                        ✅ <strong>Cara Termudah:</strong> Tunggu banner "Install FOODHUB UNIDA" muncul di bawah layar, 
                        lalu tap tombol "Install". Selesai!
                      </p>
                    </div>

                    <div className="space-y-4">
                      <h4 className="text-lg text-white">Cara Manual (jika banner tidak muncul):</h4>
                      
                      {/* Step 1 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            1
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Buka Menu Browser</h5>
                            <p className="text-gray-400 text-sm mb-3">
                              Tap tombol <strong>titik tiga (⋮)</strong> di pojok kanan atas Chrome
                            </p>
                            <div className="bg-gray-900 rounded p-3 flex items-center justify-center">
                              <MoreVertical className="h-8 w-8 text-white" />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Step 2 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            2
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Pilih "Install app" atau "Tambahkan ke layar utama"</h5>
                            <p className="text-gray-400 text-sm mb-3">
                              Cari opsi dengan icon download atau plus (+)
                            </p>
                            <div className="bg-gray-900 rounded p-3 flex items-center justify-center gap-2">
                              <Download className="h-6 w-6 text-white" />
                              <span className="text-white">Install app</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Step 3 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            3
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Konfirmasi Install</h5>
                            <p className="text-gray-400 text-sm mb-3">
                              Tap tombol <strong>"Install"</strong> di popup yang muncul
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Step 4 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white">
                            ✓
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Selesai!</h5>
                            <p className="text-gray-400 text-sm">
                              Icon <strong>FOODHUB UNIDA</strong> akan muncul di home screen atau app drawer Anda. 
                              Tap untuk membuka aplikasi! 🎉
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* iOS Tutorial */}
                {selectedPlatform === 'ios' && (
                  <div className="space-y-6">
                    <div className="text-center mb-6">
                      <div className="w-20 h-20 mx-auto bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center mb-4">
                        <Smartphone className="h-10 w-10 text-white" />
                      </div>
                      <h3 className="text-2xl text-white mb-2">Cara Install di iPhone/iPad</h3>
                      <p className="text-gray-400">Harus menggunakan Safari Browser</p>
                    </div>

                    <div className="bg-amber-900/20 border border-amber-700/50 rounded-lg p-4 mb-6">
                      <p className="text-amber-300 text-sm">
                        ⚠️ <strong>Penting:</strong> Install hanya bisa dilakukan melalui <strong>Safari</strong>, 
                        tidak bisa melalui Chrome atau browser lain di iOS!
                      </p>
                    </div>

                    <div className="space-y-4">
                      {/* Step 1 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            1
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Buka di Safari Browser</h5>
                            <p className="text-gray-400 text-sm">
                              Pastikan Anda membuka website ini di <strong>Safari</strong> (browser bawaan iPhone/iPad)
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Step 2 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            2
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Tap Tombol Share</h5>
                            <p className="text-gray-400 text-sm mb-3">
                              Tap icon <strong>Share</strong> (kotak dengan panah ke atas) di bagian bawah Safari
                            </p>
                            <div className="bg-gray-900 rounded p-3 flex items-center justify-center">
                              <Share2 className="h-8 w-8 text-blue-400" />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Step 3 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            3
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Scroll dan Pilih "Add to Home Screen"</h5>
                            <p className="text-gray-400 text-sm mb-3">
                              Scroll ke bawah di menu yang muncul, cari dan tap <strong>"Add to Home Screen"</strong>
                            </p>
                            <div className="bg-gray-900 rounded p-3 flex items-center justify-center gap-2">
                              <Plus className="h-6 w-6 text-white" />
                              <span className="text-white">Add to Home Screen</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Step 4 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            4
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Tap "Add"</h5>
                            <p className="text-gray-400 text-sm">
                              Di halaman berikutnya, tap tombol <strong>"Add"</strong> di pojok kanan atas
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Step 5 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white">
                            ✓
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Selesai!</h5>
                            <p className="text-gray-400 text-sm">
                              Icon <strong>FOODHUB UNIDA</strong> akan muncul di home screen iPhone/iPad Anda. 
                              Tap untuk membuka aplikasi! 🎉
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Desktop Tutorial */}
                {selectedPlatform === 'desktop' && (
                  <div className="space-y-6">
                    <div className="text-center mb-6">
                      <div className="w-20 h-20 mx-auto bg-blue-600 rounded-full flex items-center justify-center mb-4">
                        <Monitor className="h-10 w-10 text-white" />
                      </div>
                      <h3 className="text-2xl text-white mb-2">Cara Install di Komputer</h3>
                      <p className="text-gray-400">Chrome atau Edge Browser</p>
                    </div>

                    <div className="space-y-4">
                      {/* Step 1 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            1
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Cari Icon Install di Address Bar</h5>
                            <p className="text-gray-400 text-sm mb-3">
                              Di Chrome/Edge, lihat icon <strong>install (➕ atau ⬇)</strong> di sebelah kanan address bar (tempat URL)
                            </p>
                            <div className="bg-gray-900 rounded p-3 flex items-center gap-3">
                              <span className="text-gray-500">https://foodhub-unida.com</span>
                              <Download className="h-6 w-6 text-blue-400" />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Step 2 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            2
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Klik Icon Install</h5>
                            <p className="text-gray-400 text-sm">
                              Klik icon tersebut, atau bisa juga melalui menu <strong>⋮ → "Install FOODHUB UNIDA"</strong>
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Step 3 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            3
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Klik "Install"</h5>
                            <p className="text-gray-400 text-sm">
                              Di popup yang muncul, klik tombol <strong>"Install"</strong>
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Step 4 */}
                      <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                        <div className="flex gap-4">
                          <div className="flex-shrink-0 w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white">
                            ✓
                          </div>
                          <div className="flex-1">
                            <h5 className="text-white mb-2">Selesai!</h5>
                            <p className="text-gray-400 text-sm">
                              Aplikasi akan terbuka di window terpisah. Anda juga bisa menemukan shortcut di:
                            </p>
                            <ul className="text-gray-400 text-sm mt-2 space-y-1 list-disc list-inside">
                              <li>Desktop</li>
                              <li>Start Menu / Applications</li>
                              <li>Taskbar (bisa di-pin)</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="mt-8 pt-6 border-t border-gray-700">
                  <Button
                    onClick={onClose}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    Mengerti, Tutup Tutorial
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
