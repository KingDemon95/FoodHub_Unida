# Setup Admin Account

Untuk membuat akun admin pertama kali, ikuti langkah berikut:

## 1. Menggunakan Supabase Dashboard

1. Buka Supabase Dashboard: https://supabase.com/dashboard
2. Pilih project Anda
3. Pergi ke **Authentication** > **Users**
4. Klik **Add User** > **Create new user**
5. Isi form:
   - **Email**: admin@foodhub.com (atau email admin Anda)
   - **Password**: BuatPasswordKuatAnda
   - **User Metadata** (klik Advanced Settings):
     ```json
     {
       "name": "Admin FOODHUB",
       "role": "admin"
     }
     ```
   - Centang **Auto Confirm User**
6. Klik **Create User**
7. Copy **User ID** yang baru dibuat

## 2. Tambahkan User Data ke KV Store

Gunakan **SQL Editor** di Supabase Dashboard dan jalankan query ini:

```sql
INSERT INTO kv_store_ce9990c1 (key, value, created_at, updated_at)
VALUES (
  'user:USER_ID_YANG_ANDA_COPY',
  jsonb_build_object(
    'id', 'USER_ID_YANG_ANDA_COPY',
    'email', 'admin@foodhub.com',
    'name', 'Admin FOODHUB',
    'role', 'admin',
    'createdAt', NOW()
  ),
  NOW(),
  NOW()
);
```

**PENTING**: Ganti `USER_ID_YANG_ANDA_COPY` dengan User ID yang Anda copy di step 7.

## 3. Login

Sekarang Anda bisa login menggunakan:
- **Email**: admin@foodhub.com
- **Password**: Password yang Anda buat

---

## Kredensial Default untuk Testing

Jika Anda ingin menggunakan kredensial default untuk testing:

**Admin:**
- Email: admin@foodhub.com
- Password: admin123

**Biro Example:**
- Daftar melalui aplikasi dengan mengisi form signup
- Pilih nama biro Anda (contoh: Biro Akademik, Biro Keuangan, dll)

---

## Catatan Keamanan

⚠️ **PENTING**: 
- Ganti password default segera di production
- Aplikasi ini hanya untuk demo/development
- Jangan simpan data sensitif atau PII
