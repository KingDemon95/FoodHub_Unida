// PWA Configuration

export const PWA_CONFIG = {
  // Set to false to disable service worker completely
  enableServiceWorker: true,
  
  // Delay before registering service worker (ms)
  // This ensures app loads and API calls work before SW is registered
  registrationDelay: 3000,
  
  // Service worker scope
  scope: '/',
  
  // Update strategy
  updateViaCache: 'none' as const,
};

/**
 * Check if PWA features are supported
 */
export function isPWASupported(): boolean {
  return (
    'serviceWorker' in navigator &&
    'caches' in window &&
    'Promise' in window
  );
}

/**
 * Check if app is installed as PWA
 */
export function isInstalledPWA(): boolean {
  // Check if running in standalone mode
  if (window.matchMedia('(display-mode: standalone)').matches) {
    return true;
  }
  
  // Check iOS standalone
  if ((window.navigator as any).standalone === true) {
    return true;
  }
  
  return false;
}

/**
 * Check if device is iOS
 */
export function isIOS(): boolean {
  return /iPad|iPhone|iPod/.test(navigator.userAgent);
}

/**
 * Check if device is Android
 */
export function isAndroid(): boolean {
  return /Android/.test(navigator.userAgent);
}

/**
 * Get install prompt availability
 */
export function canShowInstallPrompt(): boolean {
  // iOS doesn't support beforeinstallprompt
  if (isIOS()) {
    return !isInstalledPWA();
  }
  
  // Android/Desktop - will be set by beforeinstallprompt event
  return true;
}
