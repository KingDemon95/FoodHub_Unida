import { useRef, useState } from "react";
import { motion } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import { Receipt, Calendar, Clock, Users, Phone, User, FileText, Download, Share2, Loader2 } from "lucide-react";
import { BookingData } from "./BookingForm";
import { OrderItem } from "./MenuSelection";
import html2canvas from "html2canvas";
import { toast } from "sonner@2.0.3";

interface InvoiceProps {
  bookingData: BookingData;
  orders: OrderItem[];
  onReset: () => void;
}

export function Invoice({ bookingData, orders, onReset }: InvoiceProps) {
  const invoiceRef = useRef<HTMLDivElement>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const subtotal = orders.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const tax = subtotal * 0.1; // 10% tax
  const total = subtotal + tax;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("id-ID", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const invoiceNumber = `INV-${Date.now().toString().slice(-8)}`;

  const captureInvoice = async (): Promise<Blob | null> => {
    if (!invoiceRef.current) return null;

    setIsGenerating(true);
    try {
      const canvas = await html2canvas(invoiceRef.current, {
        scale: 2,
        backgroundColor: "#111827",
        logging: false,
        useCORS: true,
        allowTaint: true,
        foreignObjectRendering: false,
        imageTimeout: 0,
        onclone: (clonedDoc) => {
          // Replace problematic colors with hex equivalents
          const clonedElement = clonedDoc.querySelector('[data-invoice-root]');
          if (clonedElement) {
            clonedElement.querySelectorAll('*').forEach((el) => {
              const htmlEl = el as HTMLElement;
              const computedStyle = window.getComputedStyle(el);
              
              // Convert computed colors to inline styles
              if (computedStyle.backgroundColor && computedStyle.backgroundColor !== 'rgba(0, 0, 0, 0)') {
                htmlEl.style.backgroundColor = computedStyle.backgroundColor;
              }
              if (computedStyle.color) {
                htmlEl.style.color = computedStyle.color;
              }
              if (computedStyle.borderColor) {
                htmlEl.style.borderColor = computedStyle.borderColor;
              }
            });
          }
        },
      });

      return new Promise((resolve) => {
        canvas.toBlob((blob) => {
          resolve(blob);
        }, "image/jpeg", 0.95);
      });
    } catch (error) {
      console.error("Error capturing invoice:", error);
      toast.error("Gagal mengambil screenshot invoice");
      return null;
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = async () => {
    const blob = await captureInvoice();
    if (!blob) return;

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `invoice-${invoiceNumber}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success("Invoice berhasil disimpan!");
  };

  const handleShare = async () => {
    const blob = await captureInvoice();
    if (!blob) return;

    const file = new File([blob], `invoice-${invoiceNumber}.jpg`, {
      type: "image/jpeg",
    });

    if (navigator.share && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          title: "Invoice Pesanan",
          text: `Invoice #${invoiceNumber} - Restoran Monokrom`,
          files: [file],
        });
        toast.success("Invoice berhasil dibagikan!");
      } catch (error) {
        if ((error as Error).name !== "AbortError") {
          toast.error("Gagal membagikan invoice");
        }
      }
    } else {
      // Fallback: download if share is not supported
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `invoice-${invoiceNumber}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast.info("Share tidak tersedia, invoice didownload");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.4, ease: "easeInOut" }}
      className="max-w-2xl mx-auto"
    >
      <Card 
        ref={invoiceRef} 
        data-invoice-root 
        className="border-gray-700 bg-gray-900/50 backdrop-blur-sm shadow-2xl"
      >
        <CardHeader className="text-center space-y-4 pb-8">
          <div className="flex justify-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="bg-white text-black p-4 rounded-full"
            >
              <Receipt className="h-8 w-8" />
            </motion.div>
          </div>
          <CardTitle className="text-center text-white">
            Invoice Pesanan
          </CardTitle>
          <p className="text-gray-400">
            {invoiceNumber}
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Booking Information */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gray-800/50 p-4 rounded-lg space-y-3"
          >
            <div className="flex items-center gap-2 mb-3">
              <FileText className="h-4 w-4 text-white" />
              <h3 className="text-white">Detail Reservasi</h3>
            </div>
            <div className="grid grid-cols-2 gap-3 text-gray-300">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span>{bookingData.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>{bookingData.phone}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{formatDate(bookingData.date)}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{bookingData.time}</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span>{bookingData.guests} Tamu</span>
              </div>
            </div>
            {bookingData.notes && (
              <div className="mt-3 pt-3 border-t border-gray-700">
                <p className="text-gray-400">
                  <span className="text-white">Catatan:</span> {bookingData.notes}
                </p>
              </div>
            )}
          </motion.div>

          <Separator className="bg-gray-700" />

          {/* Order Items */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-3"
          >
            <h3 className="text-white">Pesanan</h3>
            <div className="space-y-2">
              {orders.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="flex justify-between items-start py-2"
                >
                  <div className="flex-1">
                    <p className="text-white">{item.name}</p>
                    <p className="text-gray-400">
                      {item.quantity} × Rp {item.price.toLocaleString("id-ID")}
                    </p>
                  </div>
                  <p className="text-white">
                    Rp {(item.price * item.quantity).toLocaleString("id-ID")}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <Separator className="bg-gray-700" />

          {/* Totals */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="space-y-2"
          >
            <div className="flex justify-between text-gray-300">
              <span>Subtotal</span>
              <span>Rp {subtotal.toLocaleString("id-ID")}</span>
            </div>
            <div className="flex justify-between text-gray-300">
              <span>Pajak (10%)</span>
              <span>Rp {tax.toLocaleString("id-ID")}</span>
            </div>
            <Separator className="bg-gray-700" />
            <div className="flex justify-between pt-2 text-white">
              <span>Total</span>
              <span>Rp {total.toLocaleString("id-ID")}</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="pt-4 space-y-3"
          >
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={handleShare}
                disabled={isGenerating}
                variant="outline"
                className="w-full border-gray-700 bg-gray-800/50 text-white hover:bg-gray-700 transition-all duration-300 disabled:opacity-50"
              >
                {isGenerating ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Share2 className="h-4 w-4 mr-2" />
                )}
                Share
              </Button>
              <Button
                onClick={handleDownload}
                disabled={isGenerating}
                variant="outline"
                className="w-full border-gray-700 bg-gray-800/50 text-white hover:bg-gray-700 transition-all duration-300 disabled:opacity-50"
              >
                {isGenerating ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Download className="h-4 w-4 mr-2" />
                )}
                Download
              </Button>
            </div>
            <Button
              onClick={onReset}
              className="w-full bg-white text-black hover:bg-gray-200 transition-all duration-300"
            >
              Buat Pesanan Baru
            </Button>
          </motion.div>

          <p className="text-center text-gray-400 pt-4">
            Terima kasih atas pesanan Anda!
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
}