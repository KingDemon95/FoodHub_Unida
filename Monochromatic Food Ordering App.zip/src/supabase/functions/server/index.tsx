import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Create Supabase clients
const supabaseAdmin = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

const getSupabaseClient = () => createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_ANON_KEY') ?? '',
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Middleware to verify auth
const requireAuth = async (c: any, next: any) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  if (!accessToken) {
    return c.json({ error: 'Unauthorized - No token provided' }, 401);
  }

  const { data: { user }, error } = await supabaseAdmin.auth.getUser(accessToken);
  if (error || !user) {
    console.error('Auth error in requireAuth middleware:', error);
    return c.json({ error: 'Unauthorized - Invalid token' }, 401);
  }

  // Get user data from KV store
  const userData = await kv.get(`user:${user.id}`);
  if (!userData) {
    return c.json({ error: 'User data not found' }, 404);
  }

  c.set('user', userData);
  c.set('userId', user.id);
  await next();
};

// Health check endpoint
app.get("/make-server-ce9990c1/health", (c) => {
  return c.json({ status: "ok" });
});

// Sign up endpoint (for creating biro accounts)
app.post("/make-server-ce9990c1/signup", async (c) => {
  try {
    console.log('Signup endpoint hit');
    const { email, password, biroName, name } = await c.req.json();
    console.log('Signup request data:', { email, name, biroName });

    if (!email || !password || !biroName || !name) {
      console.error('Signup missing fields:', { email: !!email, password: !!password, biroName: !!biroName, name: !!name });
      return c.json({ error: 'Missing required fields' }, 400);
    }

    // Create user in Supabase Auth
    console.log('Creating user in Supabase Auth...');
    const { data, error } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm since we don't have email server
      user_metadata: { name, biroName, role: 'biro' }
    });

    if (error) {
      console.error('Error creating user in signup:', error);
      return c.json({ error: error.message }, 400);
    }

    console.log('User created successfully in Auth:', data.user.id);

    // Store user data in KV
    const userData = {
      id: data.user.id,
      email,
      name,
      biroName,
      role: 'biro',
      createdAt: new Date().toISOString(),
    };

    await kv.set(`user:${data.user.id}`, userData);
    console.log('User data stored in KV successfully');

    return c.json({ 
      message: 'User created successfully',
      user: userData 
    });
  } catch (error) {
    console.error('Error in signup endpoint:', error);
    return c.json({ error: 'Internal server error during signup' }, 500);
  }
});

// Create invoice endpoint
app.post("/make-server-ce9990c1/invoice", requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const { bookingData, orders, total } = await c.req.json();

    if (!bookingData || !orders || orders.length === 0) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    const invoiceId = `INV-${Date.now()}-${user.id.slice(0, 8)}`;
    const invoice = {
      id: invoiceId,
      biroName: user.biroName,
      biroUserId: user.id,
      biroEmail: user.email,
      bookingData,
      orders,
      total,
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`invoice:${invoiceId}`, invoice);

    // Add to invoice list
    const invoiceList = await kv.get('invoice_list') || [];
    invoiceList.unshift(invoiceId); // Add to beginning for recent first
    await kv.set('invoice_list', invoiceList);

    return c.json({ 
      message: 'Invoice created successfully',
      invoice 
    });
  } catch (error) {
    console.error('Error creating invoice:', error);
    return c.json({ error: 'Internal server error while creating invoice' }, 500);
  }
});

// Get all invoices (admin only)
app.get("/make-server-ce9990c1/invoices", requireAuth, async (c) => {
  try {
    const user = c.get('user');

    if (user.role !== 'admin') {
      return c.json({ error: 'Forbidden - Admin only' }, 403);
    }

    const invoiceList = await kv.get('invoice_list') || [];
    const invoices = await kv.mget(invoiceList.map((id: string) => `invoice:${id}`));

    return c.json({ invoices: invoices.filter(Boolean) });
  } catch (error) {
    console.error('Error fetching invoices:', error);
    return c.json({ error: 'Internal server error while fetching invoices' }, 500);
  }
});

// Get invoices for specific biro
app.get("/make-server-ce9990c1/invoices/biro", requireAuth, async (c) => {
  try {
    const user = c.get('user');

    if (user.role !== 'biro') {
      return c.json({ error: 'Forbidden - Biro only' }, 403);
    }

    const invoiceList = await kv.get('invoice_list') || [];
    const allInvoices = await kv.mget(invoiceList.map((id: string) => `invoice:${id}`));
    
    // Filter invoices for this biro
    const biroInvoices = allInvoices.filter((inv: any) => inv && inv.biroUserId === user.id);

    return c.json({ invoices: biroInvoices });
  } catch (error) {
    console.error('Error fetching biro invoices:', error);
    return c.json({ error: 'Internal server error while fetching biro invoices' }, 500);
  }
});

// Update invoice status (admin only)
app.put("/make-server-ce9990c1/invoice/:id/status", requireAuth, async (c) => {
  try {
    const user = c.get('user');

    if (user.role !== 'admin') {
      return c.json({ error: 'Forbidden - Admin only' }, 403);
    }

    const invoiceId = c.req.param('id');
    const { status } = await c.req.json();

    if (!['pending', 'completed'].includes(status)) {
      return c.json({ error: 'Invalid status' }, 400);
    }

    const invoice = await kv.get(`invoice:${invoiceId}`);
    if (!invoice) {
      return c.json({ error: 'Invoice not found' }, 404);
    }

    invoice.status = status;
    invoice.updatedAt = new Date().toISOString();

    await kv.set(`invoice:${invoiceId}`, invoice);

    return c.json({ 
      message: 'Invoice status updated',
      invoice 
    });
  } catch (error) {
    console.error('Error updating invoice status:', error);
    return c.json({ error: 'Internal server error while updating invoice status' }, 500);
  }
});

// Get user profile
app.get("/make-server-ce9990c1/profile", requireAuth, async (c) => {
  const user = c.get('user');
  return c.json({ user });
});

// Setup admin endpoint (only for initial setup)
app.post("/make-server-ce9990c1/setup-admin", async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password || !name) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    // Check if admin already exists
    const existingAdmins = await kv.getByPrefix('user:');
    const hasAdmin = existingAdmins.some((user: any) => user && user.role === 'admin');
    
    if (hasAdmin) {
      return c.json({ error: 'Admin already exists. Use normal signup for additional users.' }, 400);
    }

    // Create admin user in Supabase Auth
    const { data, error } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { name, role: 'admin' }
    });

    if (error) {
      console.error('Error creating admin user:', error);
      return c.json({ error: error.message }, 400);
    }

    // Store admin data in KV
    const adminData = {
      id: data.user.id,
      email,
      name,
      role: 'admin',
      createdAt: new Date().toISOString(),
    };

    await kv.set(`user:${data.user.id}`, adminData);

    return c.json({ 
      message: 'Admin user created successfully',
      user: adminData 
    });
  } catch (error) {
    console.error('Error in setup-admin endpoint:', error);
    return c.json({ error: 'Internal server error during admin setup' }, 500);
  }
});

Deno.serve(app.fetch);