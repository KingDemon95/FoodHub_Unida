// Dummy authentication system - tidak menggunakan Supabase
// Data dummy untuk testing dan development

export interface DummyUser {
  id: string;
  email: string;
  password: string; // In real app, this would be hashed
  name: string;
  role: "admin" | "biro";
  biroName?: string;
}

// Dummy users database
const DUMMY_USERS: DummyUser[] = [
  {
    id: "admin-001",
    email: "admin@foodhub.com",
    password: "foodhub",
    name: "Admin FOODHUB",
    role: "admin",
  },
  {
    id: "biro-001",
    email: "ti@foodhub.com",
    password: "saintek",
    name: "Biro Teknologi Informasi",
    role: "biro",
    biroName: "Biro Saintek",
  },
  {
    id: "biro-002",
    email: "akademik@foodhub.com",
    password: "akademik123",
    name: "Biro Akademik",
    role: "biro",
    biroName: "Biro Akademik",
  },
  {
    id: "biro-003",
    email: "kemahasiswaan@foodhub.com",
    password: "mawa123",
    name: "Biro Kemahasiswaan",
    role: "biro",
    biroName: "Biro Kemahasiswaan",
  },
];

// Session storage key
const SESSION_KEY = "foodhub_dummy_session";

export interface DummySession {
  user: {
    id: string;
    email: string;
    name: string;
    role: "admin" | "biro";
    biroName?: string;
  };
  accessToken: string;
  expiresAt: number;
}

// Generate dummy token
function generateToken(): string {
  return `dummy_token_${Date.now()}_${Math.random().toString(36).substring(7)}`;
}

// Login function
export async function dummyLogin(
  email: string,
  password: string
): Promise<{ user: DummySession["user"]; accessToken: string } | null> {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 500));

  const user = DUMMY_USERS.find(
    (u) => u.email === email && u.password === password
  );

  if (!user) {
    return null;
  }

  const session: DummySession = {
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      biroName: user.biroName,
    },
    accessToken: generateToken(),
    expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
  };

  // Save to localStorage
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));

  return {
    user: session.user,
    accessToken: session.accessToken,
  };
}

// Get current session
export function getDummySession(): DummySession | null {
  try {
    const sessionStr = localStorage.getItem(SESSION_KEY);
    if (!sessionStr) return null;

    const session: DummySession = JSON.parse(sessionStr);

    // Check if expired
    if (session.expiresAt < Date.now()) {
      localStorage.removeItem(SESSION_KEY);
      return null;
    }

    return session;
  } catch (error) {
    console.error("Error getting dummy session:", error);
    return null;
  }
}

// Logout
export function dummyLogout(): void {
  localStorage.removeItem(SESSION_KEY);
}

// Signup (add new biro user)
export async function dummySignup(
  email: string,
  password: string,
  name: string,
  biroName: string
): Promise<{ success: boolean; error?: string }> {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 500));

  // Check if user already exists
  const existingUser = DUMMY_USERS.find((u) => u.email === email);
  if (existingUser) {
    return { success: false, error: "Email sudah terdaftar" };
  }

  // In a real app, this would be saved to database
  // For dummy, we just add to the array (will be lost on refresh)
  const newUser: DummyUser = {
    id: `biro-${Date.now()}`,
    email,
    password,
    name,
    role: "biro",
    biroName,
  };

  DUMMY_USERS.push(newUser);

  return { success: true };
}

// Get all biro users (for admin)
export function getAllBiroUsers(): DummySession["user"][] {
  return DUMMY_USERS.filter((u) => u.role === "biro").map((u) => ({
    id: u.id,
    email: u.email,
    name: u.name,
    role: u.role,
    biroName: u.biroName,
  }));
}
