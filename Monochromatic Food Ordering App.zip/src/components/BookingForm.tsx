import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import {
  Calendar,
  Clock,
  Users,
  Briefcase,
  MessageCircle,
} from "lucide-react";

interface BookingFormProps {
  biroName?: string;
  onComplete: (data: BookingData) => void;
  onBack?: () => void;
}

export interface BookingData {
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  notes: string;
}

export function BookingForm({
  biroName,
  onComplete,
  onBack,
}: BookingFormProps) {
  const [formData, setFormData] = useState<BookingData>({
    name: "",
    phone: "",
    date: "",
    time: "",
    guests: 1,
    notes: "",
  });

  // Calculate minimum date (2 days from now)
  const getMinDate = () => {
    const today = new Date();
    today.setDate(today.getDate() + 2); // Lusa (day after tomorrow)
    return today.toISOString().split("T")[0];
  };

  const minDate = getMinDate();

  // Auto-fill biroName when provided
  useEffect(() => {
    if (biroName) {
      setFormData((prev) => ({ ...prev, name: biroName }));
    }
  }, [biroName]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete(formData);
  };

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement
    >,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === "guests" ? parseInt(value) || 1 : value,
    }));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4, ease: "easeInOut" }}
    >
      <Card className="border-gray-700 bg-gray-900/50 backdrop-blur-sm shadow-2xl">
        <CardHeader className="space-y-1">
          <CardTitle className="flex items-center gap-2 text-white">
            <Calendar className="h-5 w-5" />
            Informasi Booking
          </CardTitle>
          <CardDescription className="text-gray-400">
            Masukkan detail reservasi Anda
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label
                htmlFor="name"
                className="flex items-center gap-2 text-gray-300"
              >
                <Briefcase className="h-4 w-4" />
                Biro Usaha
              </Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                disabled={!!biroName}
                className="border-gray-700 bg-gray-800/50 text-white placeholder:text-gray-500 focus:border-gray-500 transition-colors disabled:opacity-50"
                placeholder={
                  biroName || "Masukkan nama biro usaha"
                }
              />
              {biroName && (
                <p className="text-gray-500">
                  Otomatis terisi dari akun Anda
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label
                htmlFor="phone"
                className="flex items-center gap-2 text-gray-300"
              >
                <MessageCircle className="h-4 w-4" />
                ID Telegram
              </Label>
              <Input
                id="phone"
                name="phone"
                type="text"
                value={formData.phone}
                onChange={handleChange}
                required
                className="border-gray-700 bg-gray-800/50 text-white placeholder:text-gray-500 focus:border-gray-500 transition-colors"
                placeholder="@username atau ID Telegram"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label
                  htmlFor="date"
                  className="flex items-center gap-2 text-gray-300"
                >
                  <Calendar className="h-4 w-4" />
                  Tanggal
                </Label>
                <Input
                  id="date"
                  name="date"
                  type="date"
                  value={formData.date}
                  onChange={handleChange}
                  required
                  min={minDate}
                  className="border-gray-700 bg-gray-800/50 text-white placeholder:text-gray-500 focus:border-gray-500 transition-colors"
                />
                <p className="text-xs text-amber-400">
                  ⚠️ Minimal pemesanan H-2 (lusa)
                </p>
              </div>

              <div className="space-y-2">
                <Label
                  htmlFor="time"
                  className="flex items-center gap-2 text-gray-300"
                >
                  <Clock className="h-4 w-4" />
                  Waktu
                </Label>
                <Input
                  id="time"
                  name="time"
                  type="time"
                  value={formData.time}
                  onChange={handleChange}
                  required
                  className="border-gray-700 bg-gray-800/50 text-white placeholder:text-gray-500 focus:border-gray-500 transition-colors"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label
                htmlFor="guests"
                className="flex items-center gap-2 text-gray-300"
              >
                <Users className="h-4 w-4" />
                Jumlah Tamu
              </Label>
              <Input
                id="guests"
                name="guests"
                type="number"
                min="1"
                value={formData.guests}
                onChange={handleChange}
                required
                placeholder="Masukkan jumlah tamu (tidak terbatas)"
                className="border-gray-700 bg-gray-800/50 text-white placeholder:text-gray-500 focus:border-gray-500 transition-colors"
              />
              <p className="text-xs text-gray-400">
                * Bisa memesan untuk jumlah besar (ratusan
                hingga ribuan orang)
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="text-gray-300">
                Permintaan Khusus (Opsional)
              </Label>
              <textarea
                id="notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                className="flex min-h-[80px] w-full rounded-md border border-gray-700 bg-gray-800/50 px-3 py-2 text-white placeholder:text-gray-500 focus:border-gray-500 focus:outline-none focus:ring-1 focus:ring-gray-500 transition-colors resize-none"
                placeholder="Tulis permintaan khusus Anda disini..."
              />
            </div>

            <div className="flex gap-3">
              {onBack && (
                <Button
                  type="button"
                  onClick={onBack}
                  variant="outline"
                  className="flex-1 border-gray-700 bg-gray-800/50 text-white hover:bg-gray-700 transition-all duration-300"
                >
                  Kembali
                </Button>
              )}
              <Button
                type="submit"
                className="flex-1 bg-white text-black hover:bg-gray-200 transition-all duration-300"
              >
                Lanjut ke Menu
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
}