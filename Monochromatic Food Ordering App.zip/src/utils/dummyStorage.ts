// Dummy storage for invoices - using localStorage
// Simulates database storage without Supabase

export interface DummyInvoice {
  id: string;
  userId: string;
  userName: string;
  biroName: string;
  biroUsaha: string;
  telegramId: string;
  date: string;
  time: string;
  guests: number;
  notes?: string;
  orders: {
    name: string;
    price: number;
    quantity: number;
  }[];
  total: number;
  status: "pending" | "completed";
  createdAt: string;
}

const INVOICES_KEY = "foodhub_invoices";

// Get all invoices
export function getAllInvoices(): DummyInvoice[] {
  try {
    const invoicesStr = localStorage.getItem(INVOICES_KEY);
    if (!invoicesStr) return [];
    return JSON.parse(invoicesStr);
  } catch (error) {
    console.error("Error getting invoices:", error);
    return [];
  }
}

// Get invoices by user
export function getInvoicesByUser(userId: string): DummyInvoice[] {
  const allInvoices = getAllInvoices();
  return allInvoices.filter((inv) => inv.userId === userId);
}

// Create new invoice
export function createInvoice(
  userId: string,
  userName: string,
  biroName: string,
  bookingData: {
    biroUsaha: string;
    telegramId: string;
    date: string;
    time: string;
    guests: number;
    notes?: string;
  },
  orders: {
    name: string;
    price: number;
    quantity: number;
  }[],
  total: number
): DummyInvoice {
  const newInvoice: DummyInvoice = {
    id: `INV-${Date.now()}-${Math.random().toString(36).substring(7)}`,
    userId,
    userName,
    biroName,
    biroUsaha: bookingData.biroUsaha,
    telegramId: bookingData.telegramId,
    date: bookingData.date,
    time: bookingData.time,
    guests: bookingData.guests,
    notes: bookingData.notes,
    orders,
    total,
    status: "pending",
    createdAt: new Date().toISOString(),
  };

  const allInvoices = getAllInvoices();
  allInvoices.push(newInvoice);
  localStorage.setItem(INVOICES_KEY, JSON.stringify(allInvoices));

  return newInvoice;
}

// Update invoice status
export function updateInvoiceStatus(
  invoiceId: string,
  status: "pending" | "completed"
): boolean {
  try {
    const allInvoices = getAllInvoices();
    const invoiceIndex = allInvoices.findIndex((inv) => inv.id === invoiceId);

    if (invoiceIndex === -1) {
      return false;
    }

    allInvoices[invoiceIndex].status = status;
    localStorage.setItem(INVOICES_KEY, JSON.stringify(allInvoices));
    return true;
  } catch (error) {
    console.error("Error updating invoice status:", error);
    return false;
  }
}

// Get invoice by ID
export function getInvoiceById(invoiceId: string): DummyInvoice | null {
  const allInvoices = getAllInvoices();
  return allInvoices.find((inv) => inv.id === invoiceId) || null;
}

// Delete invoice (optional)
export function deleteInvoice(invoiceId: string): boolean {
  try {
    const allInvoices = getAllInvoices();
    const filteredInvoices = allInvoices.filter((inv) => inv.id !== invoiceId);
    localStorage.setItem(INVOICES_KEY, JSON.stringify(filteredInvoices));
    return true;
  } catch (error) {
    console.error("Error deleting invoice:", error);
    return false;
  }
}

// Clear all invoices (for testing)
export function clearAllInvoices(): void {
  localStorage.removeItem(INVOICES_KEY);
}

// Initialize with dummy data if empty
export function initializeDummyData(): void {
  const existing = getAllInvoices();
  if (existing.length > 0) return; // Already has data

  const dummyInvoices: DummyInvoice[] = [
    {
      id: "INV-2025-001",
      userId: "biro-001",
      userName: "Biro Teknologi Informasi",
      biroName: "Biro Saintek",
      biroUsaha: "Biro TI",
      telegramId: "@biro_ti",
      date: "2025-01-28",
      time: "12:00",
      guests: 10,
      notes: "Mohon makanan disiapkan lebih awal, akan ada rapat penting jam 12:00",
      orders: [
        { name: "Nasi Ayam (Ustadz Ahmad)", price: 15000, quantity: 5 },
        { name: "Nasi Ikan (Ustadz Budi)", price: 15000, quantity: 5 },
        { name: "Gorengan (Ustadz Ahmad)", price: 2500, quantity: 20 },
      ],
      total: 203500,
      status: "pending",
      createdAt: "2025-01-26T08:00:00.000Z",
    },
    {
      id: "INV-2025-002",
      userId: "biro-001",
      userName: "Biro Teknologi Informasi",
      biroName: "Biro Saintek",
      biroUsaha: "Biro TI",
      telegramId: "@biro_ti",
      date: "2025-01-27",
      time: "13:00",
      guests: 5,
      orders: [
        { name: "Buah Apel", price: 5000, quantity: 10 },
        { name: "Beverage - Teh", price: 7000, quantity: 5 },
      ],
      total: 93500,
      status: "completed",
      createdAt: "2025-01-25T10:30:00.000Z",
    },
    {
      id: "INV-2025-003",
      userId: "biro-002",
      userName: "Biro Akademik",
      biroName: "Biro Akademik",
      biroUsaha: "Akademik",
      telegramId: "@akademik_unida",
      date: "2025-01-29",
      time: "11:30",
      guests: 15,
      notes: "Tolong buahnya dipotong kecil-kecil untuk memudahkan makan. Terima kasih!",
      orders: [
        { name: "Nasi Telur (Ustadz Yusuf)", price: 15000, quantity: 15 },
        { name: "Buah Jeruk", price: 6000, quantity: 15 },
        { name: "Bakkery - Roti", price: 7000, quantity: 10 },
      ],
      total: 425700,
      status: "pending",
      createdAt: "2025-01-26T09:15:00.000Z",
    },
    {
      id: "INV-2025-004",
      userId: "biro-003",
      userName: "Biro Kemahasiswaan",
      biroName: "Biro Kemahasiswaan",
      biroUsaha: "Kemahasiswaan",
      telegramId: "@mawa_unida",
      date: "2025-01-30",
      time: "14:00",
      guests: 20,
      orders: [
        { name: "Nasi Ayam (Ustadz Ahmad)", price: 15000, quantity: 10 },
        { name: "Nasi Ikan (Ustadz Budi)", price: 15000, quantity: 10 },
        { name: "Gorengan (Ustadz Budi)", price: 2500, quantity: 30 },
        { name: "Beverage - Kopi", price: 7000, quantity: 20 },
      ],
      total: 577500,
      status: "pending",
      createdAt: "2025-01-26T11:00:00.000Z",
    },
    {
      id: "INV-2025-005",
      userId: "biro-002",
      userName: "Biro Akademik",
      biroName: "Biro Akademik",
      biroUsaha: "Akademik",
      telegramId: "@akademik_unida",
      date: "2025-01-26",
      time: "12:30",
      guests: 8,
      orders: [
        { name: "Buah Pisang", price: 4000, quantity: 16 },
        { name: "Beverage - Jus", price: 7000, quantity: 8 },
      ],
      total: 132000,
      status: "completed",
      createdAt: "2025-01-24T14:20:00.000Z",
    },
  ];

  localStorage.setItem(INVOICES_KEY, JSON.stringify(dummyInvoices));
}
