# 📱 CARA DOWNLOAD APLIKASI FOODHUB UNIDA

## 🎯 Ringkasan Singkat

Aplikasi FOODHUB UNIDA **TIDAK ADA DI PLAY STORE atau APP STORE**.  
Anda install **langsung dari website** melalui browser. **100% GRATIS & AMAN!** ✅

---

## 📲 ANDROID (Paling Mudah!)

### Cara Otomatis (Direkomendasikan):
1. **Buka website** FOODHUB UNIDA di Chrome/Edge
2. **Tunggu banner** "Install FOODHUB UNIDA" muncul di bawah layar
3. **Tap "Install"** → Selesai! 🎉

### Cara Manual:
1. Tap **⋮** (titik tiga) di pojok kanan atas Chrome
2. Pilih **"Install app"** atau **"Tambahkan ke layar utama"**
3. Tap **"Install"**
4. Selesai! Icon muncul di home screen 🎉

---

## 🍎 IPHONE/IPAD

**PENTING:** Harus pakai **Safari** browser (bukan Chrome!)

1. Buka website di **Safari**
2. Tap tombol **Share** (📤 kotak + panah ke atas) di bawah
3. Scroll ke bawah, tap **"Add to Home Screen"**
4. Tap **"Add"** di pojok kanan atas
5. Selesai! Icon muncul di home screen 🎉

---

## 💻 KOMPUTER (Windows/Mac)

1. Buka website di **Chrome** atau **Edge**
2. Klik icon **Install (➕)** di address bar (sebelah URL)
3. Klik **"Install"**
4. Aplikasi terbuka di window sendiri! 🎉

---

## ❓ Kenapa Tidak Ada di Play Store/App Store?

Ini adalah **Progressive Web App (PWA)** - teknologi modern yang memungkinkan website berfungsi seperti aplikasi native TANPA perlu upload ke store.

**Keuntungan:**
- ✅ Tidak perlu download dari store
- ✅ Update otomatis (selalu versi terbaru)
- ✅ Lebih ringan dan cepat
- ✅ Data lebih aman (langsung dari server resmi)
- ✅ Bisa di-uninstall kapan saja

---

## 🔍 Cara Buka Tutorial di Aplikasi

1. Cari tombol **"Download App"** (biru, floating) di pojok kanan bawah
2. Klik untuk melihat tutorial lengkap dengan gambar
3. Pilih perangkat Anda (Android/iOS/Komputer)

---

## 💡 Tips

- **Android:** Paling mudah, ada banner install otomatis
- **iPhone:** Harus pakai Safari, tidak bisa Chrome
- **Komputer:** Install untuk akses cepat dari desktop

---

## 🆘 Butuh Bantuan?

**Banner tidak muncul?**
- Gunakan cara manual (lihat di atas)
- Clear cache browser
- Refresh halaman

**Sudah install tapi icon tidak muncul?**
- Tunggu beberapa detik
- Restart HP
- Coba install ulang

**Masih bingung?**
- Klik tombol **"Download App"** di aplikasi
- Ikuti tutorial step-by-step dengan gambar

---

## ✨ Setelah Install

Aplikasi akan:
- 📱 Muncul di home screen seperti app biasa
- 🚀 Buka lebih cepat tanpa browser bar
- 📴 Beberapa fitur bisa diakses offline
- 🔄 Update otomatis tanpa download ulang

---

**Selamat menikmati FOODHUB UNIDA! 🍔🍕🍰**
