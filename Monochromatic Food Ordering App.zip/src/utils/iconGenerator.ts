import React from 'react';

// Generate icon as SVG and convert to PNG via canvas
export function generateAppIcon(size: number): Promise<Blob> {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    // Background
    ctx.fillStyle = '#111827';
    ctx.fillRect(0, 0, size, size);

    // Draw food icon (simplified utensils)
    ctx.fillStyle = '#FFFFFF';
    
    // Fork (left)
    const forkX = size * 0.3;
    const forkY = size * 0.3;
    const forkHeight = size * 0.4;
    const forkWidth = size * 0.08;
    
    // Fork handle
    ctx.fillRect(forkX - forkWidth/2, forkY, forkWidth, forkHeight);
    
    // Fork prongs
    const prongWidth = forkWidth * 0.3;
    const prongHeight = size * 0.15;
    ctx.fillRect(forkX - forkWidth, forkY - prongHeight, prongWidth, prongHeight);
    ctx.fillRect(forkX - forkWidth/3, forkY - prongHeight, prongWidth, prongHeight);
    ctx.fillRect(forkX + forkWidth/3, forkY - prongHeight, prongWidth, prongHeight);

    // Knife (right)
    const knifeX = size * 0.7;
    const knifeY = size * 0.3;
    const knifeHeight = size * 0.4;
    const knifeWidth = size * 0.08;
    
    // Knife handle
    ctx.fillRect(knifeX - knifeWidth/2, knifeY, knifeWidth, knifeHeight);
    
    // Knife blade
    ctx.beginPath();
    ctx.moveTo(knifeX, knifeY);
    ctx.lineTo(knifeX - knifeWidth, knifeY - size * 0.2);
    ctx.lineTo(knifeX + knifeWidth, knifeY - size * 0.2);
    ctx.closePath();
    ctx.fill();

    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
    }, 'image/png');
  });
}

// Helper function to download generated icons
export async function downloadIcons() {
  const icon192 = await generateAppIcon(192);
  const icon512 = await generateAppIcon(512);

  const downloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  downloadBlob(icon192, 'icon-192.png');
  downloadBlob(icon512, 'icon-512.png');
}
