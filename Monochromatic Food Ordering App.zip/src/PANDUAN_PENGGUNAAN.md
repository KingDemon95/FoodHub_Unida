# Panduan Penggunaan FOODHUB UNIDA

Aplikasi pemesanan makanan untuk restoran FOODHUB UNIDA dengan sistem multi-user (Admin & Biro).

## 🚀 Cara Memulai

### 1. Setup Admin (Pertama Kali)

Ketika pertama kali membuka aplikasi:

1. Klik tombol **"Belum ada admin? Setup Admin Pertama"** di halaman login
2. Isi data admin:
   - **Nama Admin**: Nama lengkap administrator
   - **Email Admin**: admin@foodhub.com (atau email pilihan Anda)
   - **Password**: Password yang kuat (min. 6 karakter)
3. Klik **"Buat Akun Admin"**
4. Setelah berhasil, Anda akan kembali ke halaman login

**Default credentials untuk testing:**
- Email: admin@foodhub.com
- Password: admin123

⚠️ **Catatan**: Admin hanya bisa dibuat sekali saat setup awal!

---

## 👥 Untuk BIRO (Pengguna)

### Daftar Akun Biro

1. Di halaman login, klik **"Belum punya akun? Daftar"**
2. Isi form pendaftaran:
   - **Nama Lengkap**: Nama Anda
   - **Nama Biro**: Nama biro Anda (contoh: Biro Akademik, Biro Keuangan, dll)
   - **Email**: Email untuk login
   - **Password**: Password untuk login
3. Klik **"Daftar"**
4. Setelah berhasil, login menggunakan email dan password yang telah dibuat

### Login & Membuat Pesanan

1. **Login** menggunakan email dan password Anda
2. Klik **"Buat Pesanan Baru"**
3. **Isi Form Booking**:
   - Biro Usaha (otomatis terisi dari akun Anda)
   - ID Telegram
   - Tanggal booking
   - Waktu
   - Jumlah tamu
   - Permintaan khusus (opsional)
4. **Pilih Menu**:
   - Navigasi hierarkis dengan kategori:
     - **Madamat** → Pilih Ustadz → Pilih Nasi atau Gorengan
     - **Buah** → Pilih langsung dari daftar buah
     - **Bakkery** → Pilih roti/kue
     - **Beverage** → Pilih minuman
   - Klik **"Tambah"** untuk menambahkan item
   - Gunakan counter (+/-) untuk mengatur jumlah
5. **Lihat Invoice**:
   - Review pesanan Anda
   - **Download** invoice sebagai JPEG
   - **Share** invoice via Web Share API
6. Klik **"Buat Pesanan Baru"** untuk membuat pesanan lagi

---

## 👨‍💼 Untuk ADMIN

### Login Admin

1. Login menggunakan email dan password admin yang sudah dibuat saat setup
2. Anda akan masuk ke **Admin Dashboard**

### Fitur Admin Dashboard

#### 📊 **Statistics Cards**
- **Total Invoice**: Jumlah semua invoice
- **Pending**: Invoice yang belum diproses (warna kuning)
- **Completed**: Invoice yang sudah selesai (warna hijau)

#### 📋 **Daftar Invoice**
- Filter invoice berdasarkan status:
  - **Semua**: Tampilkan semua invoice
  - **Pending**: Hanya invoice yang belum diproses
  - **Completed**: Hanya invoice yang sudah selesai
- Klik invoice untuk melihat detail lengkap
- Informasi yang ditampilkan:
  - Invoice ID
  - Nama Biro yang memesan
  - Tanggal & waktu booking
  - Total harga
  - Waktu pembuatan invoice

#### 🔍 **Detail Invoice** (Panel Kanan)
Ketika Anda klik invoice, akan tampil detail lengkap:
- **Invoice ID**
- **Info Biro**: Nama biro & email
- **Info Booking**: Nama, telepon, tanggal, waktu, jumlah tamu
- **Daftar Pesanan**: Item yang dipesan dengan harga
- **Total Harga**
- **Tombol Aksi**:
  - 🟢 **Tandai Selesai** (untuk invoice pending)
  - 🔴 **Kembalikan ke Pending** (untuk invoice completed)

#### 📅 **Jadwal Booking** (Panel Kanan Bawah)
- Kalender otomatis yang menampilkan semua booking
- Update otomatis ketika ada invoice baru
- Warna indikator:
  - **Kuning**: Booking pending
  - **Hijau**: Booking completed
- Informasi per booking:
  - Tanggal booking
  - Waktu
  - Nama biro
  - Jumlah tamu

#### 🔔 **Real-time Updates**
- Dashboard melakukan polling setiap 10 detik untuk update invoice baru
- Notifikasi toast muncul ketika ada perubahan status

---

## 🍽️ Menu FOODHUB UNIDA

### Madamat (12 Ustadz)
- Ustadz Asif, Cecep, Nur Hadi, Fairuz, Suyanto, Setyono, Abu Darda, Hilmi, Andi, Rizqon, Eli, Huda
- Setiap Ustadz memiliki:
  - **Nasi (Rp 15.000)**: Pilihan Ikan / Ayam / Telur
  - **Gorengan (Rp 2.500)**: Jenis berbeda per Ustadz

### Buah
- Anggur (Rp 80.000)
- Kelengkeng (Rp 80.000)
- Apel (Rp 40.000)
- Jeruk (Rp 30.000)
- Melon (Rp 25.000)
- Pisang (Rp 25.000)
- Salak (Rp 20.000)
- Semangka (Rp 15.000)

### Bakkery (Semua Rp 7.000)
- Keju dalam, Coklat dalam, Sosis lilit, Pizza, Roti O, Croissant, Klappertaart, Gunung meletus, Roti bunga coklat, Donut, Piscok, Kukus bunga mekar

### Beverage (Semua Rp 7.000)
- Teh, Jus Jambu, Jus Mangga, Jus Alpukat, Jus Jeruk, Capcin, Minuman Jelly, Cheese Milk, Kopi, Rosela, Talang, Lemon Tea

---

## 💰 Perhitungan Harga

- **Subtotal**: Total harga semua item yang dipesan
- **Pajak**: 10% dari subtotal
- **Total**: Subtotal + Pajak

---

## 🎨 Fitur UI/UX

- **Tema Monokromatik Dark**: Desain modern dengan dominasi hitam dan abu-abu
- **Animasi Halus**: Transisi smooth menggunakan Motion (Framer Motion)
- **Responsive**: Berfungsi di desktop, tablet, dan mobile
- **Real-time Notifications**: Toast notifications untuk setiap aksi
- **Breadcrumb Navigation**: Navigasi hierarkis yang mudah di menu selection

---

## 🔐 Keamanan

- Authentication menggunakan Supabase Auth
- Role-based access control (Admin & Biro)
- Protected routes dan endpoints
- Auto-confirm email (karena belum ada email server)
- Session management

---

## ⚠️ Catatan Penting

1. **Hanya untuk Demo/Development**: Jangan simpan data sensitif atau PII
2. **Ganti Password Default**: Ubah password admin123 di production
3. **Internet Required**: Aplikasi memerlukan koneksi internet untuk Supabase
4. **Browser Modern**: Gunakan browser yang mendukung Web Share API untuk fitur share

---

## 🆘 Troubleshooting

### Login Gagal
- Pastikan email dan password benar
- Cek koneksi internet
- Lihat console browser untuk error detail

### Invoice Tidak Muncul di Admin
- Refresh halaman
- Tunggu 10 detik untuk auto-polling
- Pastikan invoice status tidak di-filter

### Share Tidak Berfungsi
- Web Share API tidak didukung di semua browser
- Fallback: Invoice akan di-download otomatis

---

## 📞 Support

Untuk pertanyaan atau bantuan, hubungi administrator sistem FOODHUB UNIDA.

---

**Version**: 1.0.0  
**Last Updated**: December 14, 2025  
**Powered by**: React + Supabase + Tailwind CSS + Motion
