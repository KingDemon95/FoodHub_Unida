import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { LogOut, Building2 } from "lucide-react";
import { Button } from "./ui/button";
import { BookingForm, BookingData } from "./BookingForm";
import { MenuSelection, OrderItem } from "./MenuSelection";
import { Invoice } from "./Invoice";
import { createInvoice } from "../utils/dummyStorage";
import { toast } from "sonner@2.0.3";

interface BiroDashboardProps {
  user: any;
  accessToken: string;
  onLogout: () => void;
}

export function BiroDashboard({ user, accessToken, onLogout }: BiroDashboardProps) {
  const [step, setStep] = useState<"landing" | "booking" | "menu" | "invoice">("landing");
  const [bookingData, setBookingData] = useState<BookingData | null>(null);
  const [orders, setOrders] = useState<OrderItem[]>([]);

  const handleBookingComplete = (data: BookingData) => {
    setBookingData(data);
    setStep("menu");
  };

  const handleMenuComplete = async (selectedOrders: OrderItem[]) => {
    setOrders(selectedOrders);

    // Calculate total
    const subtotal = selectedOrders.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const tax = subtotal * 0.1;
    const total = subtotal + tax;

    // Submit invoice to dummy storage
    try {
      if (!bookingData) {
        toast.error("Data booking tidak ditemukan");
        return;
      }

      const invoice = createInvoice(
        user.id,
        user.name,
        user.biroName,
        bookingData,
        selectedOrders,
        total
      );

      console.log("Invoice created:", invoice);
      toast.success("Invoice berhasil dibuat!");
      setStep("invoice");
    } catch (error) {
      console.error("Error submitting invoice:", error);
      toast.error("Terjadi kesalahan saat menyimpan invoice");
    }
  };

  const handleReset = () => {
    setStep("landing");
    setBookingData(null);
    setOrders([]);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header - Only show when not on invoice */}
      {step !== "invoice" && (
        <div className="p-4 md:p-6 border-b border-gray-800">
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="bg-white text-black p-2 rounded-lg">
                <Building2 className="h-5 w-5" />
              </div>
              <div>
                <p className="text-white">{user.biroName}</p>
                <p className="text-gray-400">{user.name}</p>
              </div>
            </div>
            <Button
              onClick={onLogout}
              variant="outline"
              className="border-gray-700 bg-gray-800/50 text-white hover:bg-gray-700"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="p-4 md:p-8">
        <AnimatePresence mode="wait">
          {step === "landing" && (
            <motion.div
              key="landing"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.4 }}
              className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] space-y-8"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 150 }}
                className="text-center space-y-4"
              >
                <h1 className="text-white">FOODHUB UNIDA</h1>
                <p className="text-gray-400">Sistem Pemesanan Makanan</p>
                <p className="text-gray-500">{user.biroName}</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <Button
                  onClick={() => setStep("booking")}
                  className="bg-white text-black hover:bg-gray-200 transition-all duration-300 px-12 py-6"
                >
                  Buat Pesanan Baru
                </Button>
              </motion.div>
            </motion.div>
          )}

          {step === "booking" && (
            <motion.div
              key="booking"
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.4 }}
            >
              <BookingForm
                biroName={user.biroName}
                onComplete={handleBookingComplete}
                onBack={() => setStep("landing")}
              />
            </motion.div>
          )}

          {step === "menu" && bookingData && (
            <motion.div
              key="menu"
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.4 }}
            >
              <MenuSelection
                onComplete={handleMenuComplete}
                onBack={() => setStep("booking")}
              />
            </motion.div>
          )}

          {step === "invoice" && bookingData && orders.length > 0 && (
            <motion.div
              key="invoice"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.4 }}
            >
              <Invoice
                bookingData={bookingData}
                orders={orders}
                onReset={handleReset}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
