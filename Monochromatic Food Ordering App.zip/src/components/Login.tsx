import { useState } from "react";
import { motion } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { LogIn, UserPlus, Loader2, User } from "lucide-react";
import { toast } from "sonner@2.0.3";
import { dummyLogin, dummySignup } from "../utils/dummyAuth";

interface LoginProps {
  onLoginSuccess: (user: any, accessToken: string) => void;
  onSetupAdmin?: () => void;
}

export function Login({ onLoginSuccess, onSetupAdmin }: LoginProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: "",
    biroName: "",
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const result = await dummyLogin(formData.email, formData.password);

      if (!result) {
        toast.error("Email atau password salah");
        setIsLoading(false);
        return;
      }

      toast.success(`Selamat datang, ${result.user.name}!`);
      onLoginSuccess(result.user, result.accessToken);
    } catch (error) {
      console.error("Login error:", error);
      toast.error("Terjadi kesalahan saat login");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const result = await dummySignup(
        formData.email,
        formData.password,
        formData.name,
        formData.biroName
      );

      if (!result.success) {
        toast.error(result.error || "Gagal membuat akun");
        setIsLoading(false);
        return;
      }

      toast.success("Akun berhasil dibuat! Silakan login.");
      setIsLogin(true);
      setFormData({ email: formData.email, password: "", name: "", biroName: "" });
    } catch (error) {
      console.error("Signup error:", error);
      toast.error("Terjadi kesalahan saat membuat akun");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <Card className="border-gray-700 bg-gray-900/50 backdrop-blur-sm shadow-2xl">
            <CardHeader className="text-center space-y-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="flex justify-center"
              >
                <div className="bg-white text-black p-4 rounded-full">
                  <User className="h-8 w-8" />
                </div>
              </motion.div>
              <CardTitle className="text-white">
                {isLogin ? "Login" : "Daftar Akun Biro"}
              </CardTitle>
              <p className="text-gray-400">FOODHUB UNIDA</p>
            </CardHeader>

            <CardContent>
              <form onSubmit={isLogin ? handleLogin : handleSignup} className="space-y-4">
                {!isLogin && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-gray-300">
                        Nama Lengkap
                      </Label>
                      <Input
                        id="name"
                        type="text"
                        placeholder="Nama Anda"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData({ ...formData, name: e.target.value })
                        }
                        required
                        className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="biroName" className="text-gray-300">
                        Nama Biro
                      </Label>
                      <Input
                        id="biroName"
                        type="text"
                        placeholder="Contoh: Biro Akademik"
                        value={formData.biroName}
                        onChange={(e) =>
                          setFormData({ ...formData, biroName: e.target.value })
                        }
                        required
                        className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                      />
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-gray-300">
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="email@example.com"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    required
                    className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-gray-300">
                    Password
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) =>
                      setFormData({ ...formData, password: e.target.value })
                    }
                    required
                    className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-white text-black hover:bg-gray-200 transition-all duration-300"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      {isLogin ? "Logging in..." : "Creating account..."}
                    </>
                  ) : (
                    <>
                      {isLogin ? (
                        <>
                          <LogIn className="h-4 w-4 mr-2" />
                          Login
                        </>
                      ) : (
                        <>
                          <UserPlus className="h-4 w-4 mr-2" />
                          Daftar
                        </>
                      )}
                    </>
                  )}
                </Button>

                <div className="text-center">
                  <button
                    type="button"
                    onClick={() => {
                      setIsLogin(!isLogin);
                      setFormData({ email: "", password: "", name: "", biroName: "" });
                    }}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    {isLogin
                      ? "Belum punya akun? Daftar"
                      : "Sudah punya akun? Login"}
                  </button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </>
  );
}